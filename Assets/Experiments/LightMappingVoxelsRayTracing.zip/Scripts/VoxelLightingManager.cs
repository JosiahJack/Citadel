using UnityEngine;
using System.Diagnostics;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine.UI;
using System;

public class VoxelLightingManager : MonoBehaviour {
    public MeshRenderer mr;
    private Stopwatch bakeTimer;
    public Texture2DArray chunkAlbedo;
    public Texture2DArray chunkGlow;
    public GameObject[] chunksToVoxelize;
    public int width = 4;
    public int voxelRenderResolution = 16;
    private int averageDivisor;
    public int debugVoxelIndex = 130;
    public float lightVolumeMultiplier = 0.5f;
    public float lightPow = 2.2f;
    public float subPow = 0.5f;
    public float rangeFac = 1.1f;
    public float rangePow = 2f;
    public float distPow = 2f;
    public float voxelFarZ = 20f;
    public float grazingDist = 0.1f;
    public float focusDistance = 1;
    public bool shadows = true;
    public bool debugLighting = false;
    public bool debugUnlit = true;
    public bool debugDepth = false;
    public bool debugWorldPos = false;
    public List<Loxel> Voxels;
    public List<Color> Lighting;
    public List<Vector3> LightingHDR;
    private Texture3D lightingTexture3D;
    private Material voxelLightingMaterial;
    public List<GameObject> DebugCubes;
    private Dictionary<Vector3Int, List<int>> VoxelMap = new Dictionary<Vector3Int, List<int>>();
    public Light[] lights;
    public bool noDebugCubes = false;
    private int iterMax;
    private int lightIndex = 0;
    private float voxelSize;
    private float voxelSizeSquared;
    private int voxelWorldMax;
    private int voxelWorldHeight;
    private Texture2D debugTex;
    private Vector3[,] colorBuffer;
    private Material matDebug;
    private float angDeg;
    private float offset;
    private int[] steps = new int[3];
    private int[] signs = new int[3];
    private int dominantAxis;
    private int traceIndex;
    private int checkIndex;
    private int pIndex;
    int[] tracePos = new int[3];
    int[] pAccumulator = new int[2]; // Error accumulators for the other two axes
    private Vector3Int traceSpot;
    private Vector3Int traceNeighbor;
    private int traceIterations;
    private int traceX;
    private int traceY;
    private float inverseNumPixels;
    
    private Matrix4x4 _matModel;
    private Matrix4x4 _matView;
    private Matrix4x4 _matProjection; 
    
    // CPU Multithreading stuff - Unused at the moment
    private NativeMultiHashMap<Vector3Int, int> voxelMapNative;
    private NativeArray<Loxel> voxelsNative;
    private NativeArray<Color> lightingOutput;
    private JobHandle jobHandle;
    
    public Camera unlitCam;
    public RenderTexture unlitPass;
    public RenderTexture unlitPassDepth;
    public RenderTexture unlitPassWorldPositions;
    public Material unlitMaterial;
    private int vertCount;
    private ComputeBuffer uvBuffer;
    private int voxCount;
    private int triangleCount;
    private ComputeBuffer trianglesBuffer;
    private ComputeBuffer verticesBuffer;
    private ComputeBuffer vertNormalsBuffer;    
    private ComputeBuffer lightingBuffer;
    private ComputeBuffer voxelPositionsBuffer;
    private ComputeBuffer voxelVec3IntsBuffer;
    private RenderTexture litPass;
    
    public ComputeShader litPassShader;
    private int litPassKernel;
    private int litPassXThreads;
    private int litPassYThreads;

    public ComputeShader rasterizerShader;
    private int rasterizerKernel;
    private int rasterizerXThreads;    

    public RawImage finalImage;

    public int renderWidth = 640;
    public int renderHeight = 480;
    public float FarZ = 1300f;
    public float FOV = 60f;
    public float NearZ = 0.02f;
    public float ViewDist = 20f; 
    
    // Light Voxel
    public struct Loxel {
        public Vector3 globalPos;
        public Vector3 normal;
        public Vector3 up;
        public Vector3 right;
        public Color diffuse;
        public Color directLighting;
        public float intensity;
        public float range;
        public int chunkObjectIndex;
        public int voxelIndex;
    }

    // Multithreading
    // =========================================================================
//     public struct LoxelLightingJob : IJobParallelFor {
//         // Input data
//         [ReadOnly] public NativeArray<Loxel> voxels;
//         [ReadOnly] public NativeMultiHashMap<Vector3Int, int> voxelMap;
//         [ReadOnly] public float voxelSize;
//         [ReadOnly] public float voxelFarZ;
//         [ReadOnly] public float iterMax;
//         [ReadOnly] public float angDeg;
//         [ReadOnly] public float offset;
//         [ReadOnly] public int voxelRenderResolution;
//         [ReadOnly] public float inverseNumPixels;
// 
//         // Output data
//         public NativeArray<Color> lightingOutput;
// 
//         public void Execute(int index) {
//             if (voxels[index].chunkObjectIndex < 0) return; // Don't light lights
// 
//             Vector3 lighting = Vector3.zero;
//             Vector3 startPos = voxels[index].globalPos + (voxels[index].normal * voxelSize);
//             Vector3Int start = GetVec3IntSpot(startPos);
//             float angleY, angleX, cosY, cosX, sinY, sinX;
//             for (int y = 0; y < voxelRenderResolution; y++) {
//                 angleY = (-angDeg * y) - offset;
//                 cosY = Mathf.Cos(angleY * Mathf.Deg2Rad);
//                 sinY = Mathf.Sin(angleY * Mathf.Deg2Rad);
//                 Vector3 rowDirection = new Vector3(
//                     cosY * voxels[index].normal.x + sinY * voxels[index].up.x,
//                     cosY * voxels[index].normal.y + sinY * voxels[index].up.y,
//                     cosY * voxels[index].normal.z + sinY * voxels[index].up.z
//                 );
// 
//                 for (int x = 0; x < voxelRenderResolution; x++) {
//                     angleX = (-angDeg * x) - offset;
//                     cosX = Mathf.Cos(angleX * Mathf.Deg2Rad);
//                     sinX = Mathf.Sin(angleX * Mathf.Deg2Rad);
//                     Vector3 rayDirection = new Vector3(
//                         cosX * rowDirection.x + sinX * voxels[index].right.x,
//                         cosX * rowDirection.y + sinX * voxels[index].right.y,
//                         cosX * rowDirection.z + sinX * voxels[index].right.z
//                     );
// 
//                     rayDirection.Normalize();
//                     Vector3 endPos = startPos + rayDirection * voxelFarZ;
//                     Vector3Int rayend = GetVec3IntSpot(endPos);
//                     int voxIndex = TraceToGetVoxel(start, rayend, rayDirection);
//                     
//                     if (voxIndex >= 0) {
//                         Color final = voxels[voxIndex].directLighting;
//                         lighting.x += final.r;
//                         lighting.y += final.g;
//                         lighting.z += final.b;
//                     }
//                 }
//             }
// 
//             lighting.x = Mathf.Min(1f, lighting.x * 0.1f);
//             lighting.y = Mathf.Min(1f, lighting.y * 0.1f);
//             lighting.z = Mathf.Min(1f, lighting.z * 0.1f);
//             lightingOutput[index] = new Color(lighting.x, lighting.y, lighting.z, 1f);
//         }
// 
//         // Helper methods would need to be integrated or adapted for use within the job context
//         private Vector3Int GetVec3IntSpot(Vector3 pos) {
//             return new Vector3Int(
//                 Mathf.RoundToInt(pos.x / voxelSize),
//                 Mathf.RoundToInt(pos.y / voxelSize),
//                 Mathf.RoundToInt(pos.z / voxelSize)
//             );
//         }
//         
//         private int GetVoxel(Vector3Int position, Vector3 rayDir) {
//             if (voxelMap.TryGetFirstValue(position, out int item, out var iterator)) {
//                 float bestDot = float.MinValue;
//                 int bestVoxel = item;
//                 while (voxelMap.TryGetNextValue(out item, ref iterator)) {
//                     float dot = Vector3.Dot(rayDir, voxels[item].normal);
//                     if (dot <= 0 && dot > bestDot) {
//                         bestDot = dot;
//                         bestVoxel = item;
//                     }
//                 }
//                 return bestVoxel;
//             }
//             return -1;
//         }
// 
//         private int TraceToGetVoxel(Vector3Int start, Vector3Int end, Vector3 raydir) {
//             int checkIndex = -1;
//             int traceIndex = 0;
//             int pIndex = 0;
//             checkIndex = GetVoxel(start, raydir); // Check starting voxel
//             if (checkIndex > 0) return checkIndex;
//             
//             int[] steps = { 0, 0, 0 };
//             int[] signs = { 0, 0, 0 };
//             steps[0] = Mathf.Abs(end.x - start.x);
//             steps[1] = Mathf.Abs(end.y - start.y);
//             steps[2] = Mathf.Abs(end.z - start.z);
//             signs[0] = end.x > start.x ? 1 : -1;
//             signs[1] = end.y > start.y ? 1 : -1;
//             signs[2] = end.z > start.z ? 1 : -1;
// 
//             // Find the axis with the greatest movement
//             int dominantAxis = 0;
//             for (traceIndex = 1; traceIndex < 3; traceIndex++) if (steps[traceIndex] > steps[dominantAxis]) dominantAxis = traceIndex;
// 
//             int[] pAccumulator = {0,0};
//             for (traceIndex = 0, pIndex = 0; traceIndex < 3; traceIndex++) {
//                 if (traceIndex != dominantAxis) {
//                     pAccumulator[pIndex++] = 2 * steps[traceIndex] - steps[dominantAxis];
//                 }
//             }
// 
//             Vector3Int tracePos = new Vector3Int(0,0,0);
//             tracePos[0] = start.x;
//             tracePos[1] = start.y;
//             tracePos[2] = start.z;
//             int traceIterations = 0;
//             Vector3Int traceSpot = new Vector3Int(0,0,0);
//             while (tracePos[dominantAxis] != end[dominantAxis]) {
//                 tracePos[dominantAxis] += signs[dominantAxis];
//                 for (traceIndex = 0, pIndex = 0; traceIndex < 3; traceIndex++) {
//                     if (traceIndex != dominantAxis) {
//                         if (pAccumulator[pIndex] >= 0) {
//                             tracePos[traceIndex] += signs[traceIndex];
//                             pAccumulator[pIndex] -= 2 * steps[dominantAxis];
//                         }
//                         pAccumulator[pIndex] += 2 * steps[traceIndex];
//                         pIndex++;
//                     }
//                 }
// 
//                 traceSpot.x = tracePos[0];
//                 traceSpot.y = tracePos[1];
//                 traceSpot.z = tracePos[2];
//                 checkIndex = GetVoxel(traceSpot, raydir);
//                 if (checkIndex > 0) return checkIndex;
// 
//                 // Only check neighbors after the first two traceIterations
//                 traceIterations++;
//                 Vector3Int traceNeighbor = new Vector3Int(0,0,0);
//                 if (traceIterations < iterMax && steps[(dominantAxis + 1) % 3] != 0 && steps[(dominantAxis + 2) % 3] != 0) { // Moving diagonally in two dimensions
//                     for (int traceX = -1; traceX <= 1; traceX++) {
//                         for (int traceY = -1; traceY <= 1; traceY++) {
//                             traceNeighbor.x = traceSpot.x + (traceX * (dominantAxis == 0 ? 0 : 1));
//                             traceNeighbor.y = traceSpot.y + (traceY * (dominantAxis == 1 ? 0 : 1));
//                             traceNeighbor.z = traceSpot.z + ((traceX + traceY == 0 ? 0 : 1) * (dominantAxis == 2 ? 0 : 1));
//                             if (traceNeighbor != traceSpot) {
//                                 checkIndex = GetVoxel(traceNeighbor, raydir);
//                                 if (checkIndex > 0) return checkIndex;
//                             }
//                         }
//                     }
//                 }
//             }
// 
//             return -1;
//         }
//     }
    
    // End Multithreading =======================================================

    void Start() {
        bakeTimer = new Stopwatch();
        bakeTimer.Start();
        colorBuffer = new Vector3[voxelRenderResolution,voxelRenderResolution];
        voxelSize = 2.56f/width;
        voxelSizeSquared = voxelSize * voxelSize;
        voxelWorldMax = 64 * width; // World is 64x64 horizontally
        if (voxelWorldMax > 2048) UnityEngine.Debug.LogError("Voxel world max cannot exceed max 2048 for Texture3D size limit!");
        voxelWorldHeight = 20 * width; // World is 20 (well I think level 8 is only 17 but whatever) cells high
        averageDivisor = voxelRenderResolution * voxelRenderResolution;
        inverseNumPixels = 1f / averageDivisor;
        debugTex = new Texture2D(voxelRenderResolution,voxelRenderResolution);
        debugTex.filterMode = FilterMode.Point;
        iterMax = width * 4; // After this many chunks, stop checking so precisely to prevent rays slipping through gaps.
        angDeg = 180f/(voxelRenderResolution + 1); // Angle distance between rays, or between end rays and perpendicular vector to Voxels[i].normal
        offset = (-90f) + angDeg;
        InitializeVoxelLists();
        CreateVoxels();
        UnityEngine.Debug.Log("Total voxels: " + Voxels.Count.ToString());
        bakeTimer.Stop();
        UnityEngine.Debug.Log("Created voxels in: " + bakeTimer.Elapsed.ToString());

        bakeTimer.Restart();
        DirectLightVoxels();
    
        // Tonemap HDR lighting into srgb color space
        for (int i=0;i<LightingHDR.Count;i++) {
            Lighting[i] = new Color(tmo(LightingHDR[i].x),
                                    tmo(LightingHDR[i].y),
                                    tmo(LightingHDR[i].z),1f);
//             Vector3Int index3D = GetVec3IntSpot(Voxels[i].globalPos); // Get 3D index into 3D texture
        }
        
        bakeTimer.Stop();
        UnityEngine.Debug.Log("Lighted voxels in: " + bakeTimer.Elapsed.ToString());
        Vector3[] voxelPositions = new Vector3[Voxels.Count];
        for (int i = 0; i < Voxels.Count; i++) {
            voxelPositions[i] = Voxels[i].globalPos;
            if (!noDebugCubes) {
                if (Voxels[i].chunkObjectIndex < 0) DebugCubes[i].GetComponent<MeshRenderer>().enabled = false;
                SetDebugCubeColor(DebugCubes[i], Lighting[i]);
            }
        }

        // Set up Unlit Pass
        List<Vector3Int> trianglesList = new List<Vector3Int>();
        List<Vector3> verticesList = new List<Vector3>();
        List<Vector4> colorsList = new List<Vector4>();
        List<Vector2> uvsList = new List<Vector2>();
        List<Vector3> vertNormalsList = new List<Vector3>();
        GameObject chunk = null;
        for (int p = 0; p < chunksToVoxelize.Length; p++) {
            chunk = chunksToVoxelize[p];
            if (chunk == null) continue;
            
            Mesh mesh = chunk.GetComponent<MeshFilter>().sharedMesh;
            Matrix4x4 localToWorld = chunk.transform.localToWorldMatrix;
            Vector3[] meshVertices = mesh.vertices;
            Vector3[] meshNorms = mesh.normals;
            Color[] meshColors = mesh.colors.Length > 0 ? mesh.colors : new Color[mesh.vertexCount];
            Vector2[] meshUVs = mesh.uv.Length > 0 ? mesh.uv : new Vector2[mesh.vertexCount];
            int[] triangles = mesh.triangles; // Triangle indices

            // Dictionary to map old indices to new indices
            Dictionary<int, int> indexMap = new Dictionary<int, int>();
            int addedVerts = 0;
            Vector3 worldPosition;
            Vector3 worldNormal;
            // Vertices, normals, colors, and UVs should be stored once per unique vertex, not per triangle
            for (int i = 0; i < meshVertices.Length; i++) {
                worldPosition = localToWorld.MultiplyPoint(meshVertices[i]);
                worldNormal = localToWorld.MultiplyVector(meshNorms[i]);
                verticesList.Add(worldPosition);
                vertNormalsList.Add(worldNormal); // Transform normals
//                 UnityEngine.Debug.DrawRay(worldPosition, worldNormal * 0.5f, Color.green, 60f);
                colorsList.Add(meshColors[i]);
                uvsList.Add(meshUVs[i]);
                indexMap[i] = verticesList.Count - 1; // Map original index to new index in verticesList
                addedVerts++;
            }

            int numTrisAdded = 0;
            for (int i = 0; i < triangles.Length; i += 3) {
                Vector3 v0 = verticesList[indexMap[triangles[i]]];
                Vector3 v1 = verticesList[indexMap[triangles[i + 1]]];
                Vector3 v2 = verticesList[indexMap[triangles[i + 2]]];

                // Calculate the area of the triangle
                Vector3 edge1 = v1 - v0;
                Vector3 edge2 = v2 - v0;
                float area = Vector3.Cross(edge1, edge2).magnitude * 0.5f;

                // Skip if the triangle is degenerate (area is very small)
                if (area > 1e-6) { // Adjust this threshold based on your scale and precision needs
                    int newIdx0 = indexMap[triangles[i]];
                    int newIdx1 = indexMap[triangles[i + 1]];
                    int newIdx2 = indexMap[triangles[i + 2]];
                    trianglesList.Add(new Vector3Int(newIdx0, newIdx2, newIdx1));
                    numTrisAdded++;
                }
            }
        }

        // Setup RenderTextures
        unlitPass = new RenderTexture(renderWidth,renderHeight, 24, RenderTextureFormat.ARGBFloat);
        unlitPass.enableRandomWrite = true;
        unlitPass.Create();
        unlitPass.name = "UnlitPassRT";
        
        unlitCam.depthTextureMode = DepthTextureMode.Depth;
        unlitCam.targetTexture = unlitPass;
        unlitCam.farClipPlane = FarZ;
        unlitCam.nearClipPlane = NearZ;
        
        unlitPassDepth = new RenderTexture(renderWidth,renderHeight, 24, RenderTextureFormat.ARGBFloat);
        unlitPassDepth.enableRandomWrite = true;
        unlitPassDepth.Create();
        unlitPassDepth.name = "UnlitPassDepthRT";
        
        unlitPassWorldPositions = new RenderTexture(renderWidth,renderHeight, 24, RenderTextureFormat.ARGBFloat);
        unlitPassWorldPositions.enableRandomWrite = true;
        unlitPassWorldPositions.Create();
        unlitPassWorldPositions.name = "UnlitPassWorldPositionsRT";
        
        // Set up Lit Pass
        lightingBuffer = new ComputeBuffer(LightingHDR.Count, sizeof(float) * 3);
        lightingBuffer.SetData(LightingHDR);
        litPass = new RenderTexture(renderWidth,renderHeight,0,RenderTextureFormat.ARGBFloat);
        litPass.enableRandomWrite = true;
        litPass.Create();
        litPass.name = "LitPassRT";
        
        // Pick output
        if (debugDepth) {
            finalImage.texture = unlitPassDepth;
        } else if (debugUnlit) {
            finalImage.texture = unlitPass;
        } else if (debugWorldPos) {
            finalImage.texture = unlitPassWorldPositions;
        } else {
            finalImage.texture = litPass;
        }
        
        voxCount = voxelPositions.Length;
        voxelPositionsBuffer = new ComputeBuffer(voxCount,sizeof(float) * 3);
        voxelPositionsBuffer.SetData(voxelPositions);
        
        Vector3Int[] voxelIndices = new Vector3Int[voxCount];
        for (int i=0;i<voxCount;i++) {
            voxelIndices[i] = GetVec3IntSpot(Voxels[i].globalPos);
        }
        voxelVec3IntsBuffer = new ComputeBuffer(voxCount,sizeof(int) * 3);
        voxelVec3IntsBuffer.SetData(voxelIndices);
        
        vertCount = verticesList.Count;
        verticesBuffer = new ComputeBuffer(vertCount,sizeof(float) * 3);
        verticesBuffer.SetData(verticesList);
        uvBuffer = new ComputeBuffer(vertCount,sizeof(float) * 2);
        uvBuffer.SetData(uvsList);
        vertNormalsBuffer = new ComputeBuffer(vertCount,sizeof(float) * 3);
        vertNormalsBuffer.SetData(vertNormalsList);
        
        triangleCount = trianglesList.Count;
        trianglesBuffer = new ComputeBuffer(triangleCount,sizeof(int) * 3);
        trianglesBuffer.SetData(trianglesList);

        litPassKernel = litPassShader.FindKernel("LitPassShader");
        litPassShader.SetBuffer(litPassKernel, "LightingHDR", lightingBuffer);
        litPassShader.SetBuffer(litPassKernel, "VoxelPositions", voxelPositionsBuffer);
        litPassShader.SetBuffer(litPassKernel, "VoxelIndices", voxelVec3IntsBuffer);
        litPassShader.SetFloat("voxelSize", voxelSize);
        litPassXThreads = Mathf.CeilToInt(litPass.width / 8.0f);
        litPassYThreads = Mathf.CeilToInt(litPass.height / 8.0f);
        
//         rasterizerKernel = rasterizerShader.FindKernel("Rasterizer");
//         rasterizerXThreads = Mathf.CeilToInt(triangleCount / 512.0f);
//         rasterizerShader.SetBuffer(rasterizerKernel, "triangleBuffer", trianglesBuffer);
//         rasterizerShader.SetBuffer(rasterizerKernel, "vertexBuffer", verticesBuffer);
//         rasterizerShader.SetBuffer(rasterizerKernel, "LightingHDR", lightingBuffer);
//         rasterizerShader.SetBuffer(rasterizerKernel, "VoxelPositions", voxelPositionsBuffer);
//         rasterizerShader.SetBuffer(rasterizerKernel, "uvBuffer", uvBuffer);
    }
    
    public static Matrix4x4 CleanMatrix(Matrix4x4 matrix) {
        float threshold = 0.0005f;
        Matrix4x4 cleanedMatrix = new Matrix4x4();
        for (int i = 0; i < 16; i++) {
            cleanedMatrix[i] = Mathf.Abs(matrix[i]) < threshold ? 0f : matrix[i];
        }
        
//         UnityEngine.Debug.Log("Cleaned: " + cleanedMatrix.ToString() + " vs old: " + matrix.ToString());
        return cleanedMatrix;
    }
    
    public void ClearOutRenderTexture(RenderTexture renderTexture, Color clearColor) {
        RenderTexture rt = RenderTexture.active;
        RenderTexture.active = renderTexture;
        GL.Clear(true, true, clearColor); // Clear both color and depth
        RenderTexture.active = rt;
    }
    
//     void Update() {
//         // We compute rasterize a little
//         ClearOutRenderTexture(litPass, Color.black); // Clear color to black
//         ClearOutRenderTexture(unlitPassDepth, Color.white);
//         RenderTexture.active = null;
// 
//         litPass.DiscardContents(true,false); // Clear color buffer
//         unlitPassDepth.DiscardContents(true,false); // Clear color buffer
//         rasterizerShader.SetTexture(rasterizerKernel, "DepthTexture", unlitPassDepth);
//         rasterizerShader.SetTexture(rasterizerKernel, "OutputTexture", litPass);
// //         rasterizerShader.SetInt("triangleCount",triangleCount);
//         rasterizerShader.SetInt("renderWidth",renderWidth);
//         rasterizerShader.SetInt("renderHeight",renderHeight);
//         rasterizerShader.SetMatrix("_ProjectionMatrix", CleanMatrix(unlitCam.projectionMatrix));
// //         rasterizerShader.SetMatrix("_InvProjectionMatrix",  Matrix4x4.Inverse(CleanMatrix(unlitCam.projectionMatrix)));
//         rasterizerShader.SetMatrix("_ViewMatrix", CleanMatrix(unlitCam.worldToCameraMatrix));
//         rasterizerShader.Dispatch(rasterizerKernel,renderWidth / 16, renderHeight / 16,1);
//     }
    
    void Update() {
        // First pass: Render depth
        unlitCam.targetTexture = unlitPassDepth;
        unlitCam.clearFlags = CameraClearFlags.SolidColor; // Clear to white for depth 1.0
        unlitCam.backgroundColor = Color.white;
        unlitCam.RenderWithShader(Shader.Find("Custom/StandardTextureArrayUnlit_DepthOnly"), "");

        // Second pass: Render color
        unlitCam.targetTexture = unlitPass;
        unlitCam.clearFlags = CameraClearFlags.Depth;
        unlitCam.RenderWithShader(Shader.Find("Custom/StandardTextureArrayUnlit"), "");
        
        // Third pass: Render world positions
        unlitCam.targetTexture = unlitPassWorldPositions;
        unlitCam.clearFlags = CameraClearFlags.Depth;
        unlitCam.RenderWithShader(Shader.Find("Custom/StandardTextureArrayUnlit_WorldPositions"), "");

        // Reset camera
        unlitCam.targetTexture = null;

        // Apply voxel lighting as Post-Processing Effect
        litPassShader.SetTexture(litPassKernel, "InputTexture", unlitPass);
        litPassShader.SetTexture(litPassKernel, "InputWorldPositions", unlitPassWorldPositions);
        litPassShader.SetTexture(litPassKernel, "OutputTexture", litPass);
//         Matrix4x4 viewMatrix = unlitCam.worldToCameraMatrix;
//         Matrix4x4 projectionMatrix = unlitCam.projectionMatrix;
//         Matrix4x4 viewProjMatrix = projectionMatrix * viewMatrix;
//         litPassShader.SetMatrix("_MatI_VP",  Matrix4x4.Inverse(viewProjMatrix));
//         litPassShader.SetMatrix("_InverseViewMatrix",  Matrix4x4.Inverse(unlitCam.worldToCameraMatrix));
//         litPassShader.SetMatrix("_InvProjectionMatrix",  Matrix4x4.Inverse(unlitCam.projectionMatrix));
//         litPassShader.SetFloat("FarZ",FarZ);
//         litPassShader.SetFloat("NearZ",NearZ);
        litPassShader.SetInt("voxelCount",voxCount);
//         litPassShader.SetInt("renderWidth",renderWidth);
//         litPassShader.SetInt("renderHeight",renderHeight);
        litPassShader.Dispatch(litPassKernel,litPassXThreads,litPassYThreads,1);
    }
    
    public static Vector3 GetWorldPositionFromUV(Vector2 uv, float depth,
                                                 Matrix4x4 cameraInvProjection,
                                                 Matrix4x4 cameraToWorld) {
        
        // Convert UV to clip space (-1 to 1 for x and y, -1 to 1 for z with depth)
        Vector4 clipPos = new Vector4(uv.x * 2 - 1, 
                                      uv.y * 2 - 1,
                                      depth * 2 - 1, 1);

        Vector4 viewPos = cameraInvProjection * clipPos; // Convert from clip space to view space
        viewPos /= viewPos.w; // Perspective divide
        Vector4 worldPos = cameraToWorld * viewPos; // Convert from view space to world space
        return worldPos;
    }
    
    // Reinhard Tonemapping Operator
    private float tmo(float hdr) {
        return hdr / (1.0f + hdr);
    }

    private bool IsCoplanar(Vector3 targetPos, Vector3 targetNormal, Vector3 pointToCheck) {
        float dist = Vector3.Dot(targetNormal,(pointToCheck - targetPos));
        return Mathf.Abs(dist) < grazingDist;
    }
    
    private int TraceToGetVoxel(Vector3Int start, Vector3Int end, Vector3 raydir) {
        checkIndex = -1;
        traceIndex = 0;
        
        checkIndex = GetVoxel(start, raydir); // Check starting voxel
        if (checkIndex > 0) {
            if (Voxels[checkIndex].chunkObjectIndex >= 0) return checkIndex;
        }

        steps[0] = Mathf.Abs(end.x - start.x);
        steps[1] = Mathf.Abs(end.y - start.y);
        steps[2] = Mathf.Abs(end.z - start.z);
        signs[0] = end.x > start.x ? 1 : -1;
        signs[1] = end.y > start.y ? 1 : -1;
        signs[2] = end.z > start.z ? 1 : -1;

        // Find the axis with the greatest movement
        dominantAxis = 0;
        for (traceIndex = 1; traceIndex < 3; traceIndex++) if (steps[traceIndex] > steps[dominantAxis]) dominantAxis = traceIndex;

        for (traceIndex = 0, pIndex = 0; traceIndex < 3; traceIndex++) {
            if (traceIndex != dominantAxis) {
                pAccumulator[pIndex++] = 2 * steps[traceIndex] - steps[dominantAxis];
            }
        }

        tracePos[0] = start.x;
        tracePos[1] = start.y;
        tracePos[2] = start.z;
        while (tracePos[dominantAxis] != end[dominantAxis]) {
            tracePos[dominantAxis] += signs[dominantAxis];
            for (traceIndex = 0, pIndex = 0; traceIndex < 3; traceIndex++) {
                if (traceIndex != dominantAxis) {
                    if (pAccumulator[pIndex] >= 0) {
                        tracePos[traceIndex] += signs[traceIndex];
                        pAccumulator[pIndex] -= 2 * steps[dominantAxis];
                    }
                    pAccumulator[pIndex] += 2 * steps[traceIndex];
                    pIndex++;
                }
            }

            traceSpot.x = tracePos[0];
            traceSpot.y = tracePos[1];
            traceSpot.z = tracePos[2];
            checkIndex = GetVoxel(traceSpot, raydir);
            if (checkIndex > 0) {
                if (Voxels[checkIndex].chunkObjectIndex >= 0) return checkIndex;
            }
        }

        return -1;
    }

    private void DirectLightVoxels() {
        Vector3 rayDirection = Vector3.zero;
        Vector3 startPos;
        Vector3Int start = new Vector3Int(0,0,0);
        Vector3Int rayend = new Vector3Int(0,0,0);
        for (int i = 0; i < Voxels.Count; i++) {
            if (Voxels[i].chunkObjectIndex >= 0) {
                if (LightingHDR[i].x < Voxels[i].directLighting.r
                    || LightingHDR[i].y < Voxels[i].directLighting.g
                    || LightingHDR[i].z < Voxels[i].directLighting.b) {
                    
                    Vector3 glowfallback = new Vector3(Voxels[i].directLighting.r,
                                                       Voxels[i].directLighting.g,
                                                       Voxels[i].directLighting.b);
                    LightingHDR[i] = glowfallback;
                }
                continue; // Don't spread light from nonlights
            }

            startPos = Voxels[i].globalPos;
            float range2 = Mathf.Pow(Voxels[i].range,rangePow) * rangeFac;
            if (shadows) start = GetVec3IntSpot(startPos);
            for (int j = 0; j < Voxels.Count; j++) {
                if (j == i) continue;
                if (Voxels[j].chunkObjectIndex < 0) continue;

                rayDirection = (Voxels[j].globalPos - startPos);
                float dot = Vector3.Dot(rayDirection,Voxels[j].normal);
                if (dot > 0) continue;

                float dist2 = rayDirection.magnitude;
                dist2 = Mathf.Pow(dist2,distPow);
                if (dist2 > range2) continue;

                if (shadows) rayend = GetVec3IntSpot(Voxels[j].globalPos);
                rayDirection = rayDirection.normalized;
                int voxIndex = -1;
                if (shadows) voxIndex = TraceToGetVoxel(start, rayend, rayDirection);
                if (!shadows || voxIndex == j
                    || (voxIndex >= 0 ?
                        IsCoplanar(Voxels[j].globalPos,
                                   Voxels[j].normal,
                                   Voxels[voxIndex].globalPos)
                        : false)) {

                    float intensity = 1f - Mathf.Pow(dist2 / range2, subPow);
                    intensity = Mathf.Pow(intensity,lightPow) * lightVolumeMultiplier * Voxels[i].intensity;
                    Vector3 newLighting = new Vector3(Voxels[i].directLighting.r,Voxels[i].directLighting.g,Voxels[i].directLighting.b);
                    newLighting.x *= intensity;
                    newLighting.y *= intensity;
                    newLighting.z *= intensity;
                    Color diff = Voxels[j].diffuse;
                    newLighting.x *= (debugLighting ? 1.0f : diff.r);
                    newLighting.y *= (debugLighting ? 1.0f : diff.g);
                    newLighting.z *= (debugLighting ? 1.0f : diff.b);
                    Color glow = Voxels[j].directLighting;
                    if (glow.r > 0f) newLighting.x = Mathf.Max(newLighting.x,glow.r);
                    if (glow.g > 0f) newLighting.y = Mathf.Max(newLighting.y,glow.g);
                    if (glow.b > 0f) newLighting.z = Mathf.Max(newLighting.z,glow.b);
                    newLighting.x += LightingHDR[j].x;
                    newLighting.y += LightingHDR[j].y;
                    newLighting.z += LightingHDR[j].z;
                    LightingHDR[j] = newLighting;
                }
            }
        }
    }

    private void SetDebugCubeColor(GameObject cube, Color col) {
        if (noDebugCubes) return;

        Material mat = new Material(Shader.Find("Unlit/Color"));
        mat.color = col;
        cube.GetComponent<Renderer>().material = mat;
    }
    
    private void AddToVoxelLists(Loxel voxel, GameObject debugCube) {
        Voxels.Add(voxel);
        if (voxel.chunkObjectIndex < 0) {
            Lighting.Add(voxel.diffuse);
        } else {
            Lighting.Add(Color.black);
        }
        
        LightingHDR.Add(Vector3.zero);
        if (!noDebugCubes) DebugCubes.Add(debugCube);
        AddVoxel(voxel);
    }
    
    private void InitializeVoxelLists() {
        Voxels = new List<Loxel>();
        DebugCubes = new List<GameObject>();
        Lighting = new List<Color>();
        LightingHDR = new List<Vector3>();
    }
    
    private void CreateVoxels() {
        Transform tr;
        Color selected;
        Color glowSelected;
        Vector3 sumColor;
        Vector3 glowColor;

        // Create geometry voxels
        for (int c=0;c<chunksToVoxelize.Length;c++) {
            tr = chunksToVoxelize[c].transform;
            
            // Get Diffuse and Glow Colors from Texture Channels
            Mesh msh = chunksToVoxelize[c].GetComponent<MeshFilter>().sharedMesh;
            float red = msh.colors[0].r;
            int chunkIndex = (int)(red * 255.0f);
            Color[] textureCols = chunkAlbedo.GetPixels(chunkIndex,0);
            Color[] textureGlow = chunkGlow.GetPixels(chunkIndex,0);
            int numPixelsInVoxel = (int)(128f / (float)width); // E.g. if width is 8, numPixelsInVoxel = 128 / 8 = 16;
            Color[] voxelColors = new Color[width * width];
            Color[] voxelGlowColors = new Color[width * width];
            for (int i = 0; i < width; i++) {
                for (int j = 0; j < width; j++) {
                    sumColor = Vector3.zero;
                    glowColor = Vector3.zero;
                    int startX = i * numPixelsInVoxel;
                    int startY = j * numPixelsInVoxel;
                    for (int pixX = startX; pixX < startX + numPixelsInVoxel; pixX++) {
                        for (int pixY = startY; pixY < startY + numPixelsInVoxel; pixY++) {
                            int texIndex = pixY * 128 + (127 - pixX);
                            selected = textureCols[texIndex];
                            glowSelected = textureGlow[texIndex];
                            sumColor.x += selected.r;
                            sumColor.y += selected.g;
                            sumColor.z += selected.b;

                            glowColor.x += glowSelected.r;
                            glowColor.y += glowSelected.g;
                            glowColor.z += glowSelected.b;
                        }
                    }

                    int totalPixels = numPixelsInVoxel * numPixelsInVoxel;
                    Color vol = new Color(
                        sumColor.x / totalPixels, // Do the average
                        sumColor.y / totalPixels, // Do the average
                        sumColor.z / totalPixels, // Do the average
                        1f
                    );

                    Color glow = new Color(
                        glowColor.x / totalPixels, // Do the average
                        glowColor.y / totalPixels, // Do the average
                        glowColor.z / totalPixels, // Do the average
                        1f
                    );

                    voxelColors[i * width + j] = vol;
                    voxelGlowColors[i * width + j] = glow;
                }
            }

            // Create the voxels along the geometry card.
            for (int x=0;x<width;x++) {
                for (int y=0;y<width;y++) {
                    float offsetX = (x * voxelSize) - 1.28f + (voxelSize * 0.5f);
                    float offsetY = 1.28f + (voxelSize * 0.5f);
                    float offsetZ = (y * voxelSize) - 1.28f + (voxelSize * 0.5f);
                    Vector3 ofs = new Vector3(offsetX, offsetY, offsetZ);
                    Vector3 ofsTP = tr.TransformPoint(ofs);
                    // Compare ofs vs ofsTP
                    const float precisionThreshold = 0.002f; // Adjust this threshold as needed
                    Vector3 globalPos;
                    if (Vector3.Distance(ofs, tr.InverseTransformPoint(ofsTP)) < precisionThreshold) {
                        // If the difference is small, use the local offset directly
                        globalPos = tr.TransformPoint(ofs);
                    } else {
                        // Otherwise, use the originally transformed and grid-aligned position
                        globalPos = new Vector3(
                            Mathf.Floor(ofsTP.x / voxelSize) * voxelSize,
                            Mathf.Floor(ofsTP.y / voxelSize) * voxelSize,
                            Mathf.Floor(ofsTP.z / voxelSize) * voxelSize
                        );
                    }

                    GameObject cube = null;
                    if (!noDebugCubes) {
                        cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        cube.transform.localScale = new Vector3(voxelSize,voxelSize,voxelSize);
                        cube.transform.position = globalPos;
//                         Note nt = cube.AddComponent<Note>();
//                         nt.note = "Chunk index: " + chunkObjectIndex.ToString() + ", Voxel index: " + voxIndex.ToString();
                    }

                    Loxel lox;
                    lox.globalPos = globalPos;
                    lox.normal = -tr.up; // Green axis, card faces down on rotation 0,0,0
                    lox.diffuse = voxelColors[x * width + y];
                    lox.directLighting = voxelGlowColors[x * width + y];
                    lox.chunkObjectIndex = c;
                    lox.voxelIndex = Voxels.Count;
                    lox.up = tr.right; // Red axis
                    lox.right = -tr.forward; // Blue axis, flipped due to card facing down in rotation 0,0,0
                    lox.range = 70f;
                    lox.intensity = 1f;
                    AddToVoxelLists(lox,cube);
                }
            }
        }

        // Create light voxels
        for (int i=0;i<lights.Length;i++) {
            Vector3 spot = lights[i].transform.position;
            CreateLightVoxel(spot,lights[i],false);
/*            
            Vector3 offset = new Vector3(0f,0f,voxelSize);
            CreateLightVoxel(spot + offset,lights[i],true);

            offset = new Vector3(0f,0f,-voxelSize);
            CreateLightVoxel(spot + offset,lights[i],true);
            
            offset = new Vector3(voxelSize,0f,0f);
            CreateLightVoxel(spot + offset,lights[i],true);
            
            offset = new Vector3(-voxelSize,0f,0f);
            CreateLightVoxel(spot + offset,lights[i],true);
            
            offset = new Vector3(0f,voxelSize,0f);
            CreateLightVoxel(spot + offset,lights[i],true);
            
            offset = new Vector3(0f,-voxelSize,0f);
            CreateLightVoxel(spot + offset,lights[i],true);*/
        }
    }
    
    private void CreateLightVoxel(Vector3 spot, Light light, bool isAreaFill) {
        Loxel lit;
        GameObject lightCube = null;
        if (!noDebugCubes) {
            lightCube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            lightCube.transform.localScale = new Vector3(voxelSize,voxelSize,voxelSize);
        }
        
        spot.x = Mathf.Floor(spot.x / voxelSize) * voxelSize;
        spot.y = Mathf.Floor(spot.y / voxelSize) * voxelSize;
        spot.z = Mathf.Floor(spot.z / voxelSize) * voxelSize;
        if (!noDebugCubes) lightCube.transform.position = spot; // Take from float position and put into grid position
        lit.globalPos = spot;//light.transform.position;
        lit.normal = Vector3.zero;
        lit.diffuse = light.color;
        if (isAreaFill) {
            float distFac = 0.5f;//1f - ((voxelSize * voxelSize)/(light.range * light.range));
            lit.diffuse.r *= distFac;
            lit.diffuse.g *= distFac;
            lit.diffuse.b *= distFac;
        }

        lit.directLighting = light.color;
        SetDebugCubeColor(lightCube,light.color);
        lit.chunkObjectIndex = -1;
        lit.voxelIndex = Voxels.Count;
        lit.up = Vector3.zero;
        lit.right = Vector3.zero;
        lit.range = light.range;
        lit.intensity = light.intensity;
        AddToVoxelLists(lit,lightCube); // Add light as a voxel
        lightIndex = Voxels.Count - 1;
    }

    private Vector3Int GetVec3IntSpot(Vector3 pos) {
        return new Vector3Int(
            Mathf.RoundToInt(pos.x / voxelSize),
            Mathf.RoundToInt(pos.y / voxelSize),
            Mathf.RoundToInt(pos.z / voxelSize)
        );
    }
    
    private Vector3 GetVec3Spot(Vector3Int posInt) {
        return new Vector3(
            (float)posInt.x * voxelSize,
            (float)posInt.y * voxelSize,
            (float)posInt.z * voxelSize
        );
    }

    private void AddVoxel(Loxel voxel) {
        Vector3Int posInt = GetVec3IntSpot(voxel.globalPos);
        if (!VoxelMap.TryGetValue(posInt, out List<int> indices)) {
            indices = new List<int>();
            VoxelMap[posInt] = indices;
        }
        indices.Add(voxel.voxelIndex);
    }

    private int GetVoxel(Vector3Int position, Vector3 rayDir) {
        if (VoxelMap.TryGetValue(position, out List<int> indices)) {
            float bestDot = float.MinValue;
            int bestVoxel = indices[0];
            for (int i = 0; i < indices.Count; i++) {
                float dot = Vector3.Dot(rayDir, Voxels[indices[i]].normal);
                if (dot <= 0 && dot > bestDot) {
                    bestDot = dot;
                    bestVoxel = indices[i];
                }
            }
            return bestVoxel;
        }
        return -1;
    }

    void OnDestroy() {
        if (jobHandle.IsCompleted == false) jobHandle.Complete();
        if (voxelsNative != null) { if (voxelsNative.IsCreated) voxelsNative.Dispose(); }
        if (lightingOutput != null) { if (lightingOutput.IsCreated) lightingOutput.Dispose(); }
        if (voxelMapNative.IsCreated) voxelMapNative.Dispose();

        // Clear the List
        if (Voxels != null) {
            Voxels.Clear();
            Voxels = null; // This step is optional, but can help with garbage collection
        }

        if (DebugCubes != null) {
            DebugCubes.Clear();
            DebugCubes = null;
        }

        // Clear the Dictionaries
        if (VoxelMap != null) {
            VoxelMap.Clear();
            VoxelMap = null;
        }

        ShaderHelper.Release(lightingBuffer);
        ShaderHelper.Release(voxelPositionsBuffer);
        ShaderHelper.Release(trianglesBuffer);
        ShaderHelper.Release(verticesBuffer);
        ShaderHelper.Release(uvBuffer);
        ShaderHelper.Release(vertNormalsBuffer);
        ShaderHelper.Release(voxelVec3IntsBuffer);
        if (unlitPass != null) unlitPass.Release();
        if (unlitPassDepth != null) unlitPassDepth.Release();
    }
}
