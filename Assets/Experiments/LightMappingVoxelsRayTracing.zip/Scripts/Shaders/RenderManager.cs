using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

[RequireComponent(typeof(Camera))]
public class RenderManager : MonoBehaviour {
    public RenderTexture renderTexture;
    public Camera renderCamera; // The camera capturing the render texture output
    public RawImage targetRawImage; // UI RawImage to display the render texture
    public ComputeShader firstPassShader;
    public Mesh[] meshes;
    public GameObject[] meshInstanceObjects;
    private MeshInstanceData[] meshInstances;
    private ComputeBuffer meshDataBuffer;
    private ComputeBuffer instanceBuffer;
    private ComputeBuffer vertexBuffer;
    private ComputeBuffer indexBuffer;
    private RenderTexture resultTexture;
    private RenderTexture depthTexture;

    struct MeshData {
        public uint vertexStart;   // Start index in the global vertex buffer
        public uint vertexCount;   // Number of vertices for this mesh
        public uint indexStart;    // Start index in the global index buffer
        public uint indexCount;    // Number of indices for this mesh
    }

    public struct MeshInstanceData {
        public Vector3 position;
        public Vector4 rotation;
        public Vector3 scale;
        public int meshIndex; // Index to distinguish between different meshes
    }

    void Start() {
        renderCamera.targetTexture = renderTexture;
        targetRawImage.canvas.worldCamera = renderCamera;
        resultTexture = new RenderTexture(1920, 1080, 0);
        resultTexture.enableRandomWrite = true; // Enable UAV (unordered access view)
        resultTexture.Create();

        depthTexture = new RenderTexture(1920, 1080, 0);
        depthTexture.enableRandomWrite = true; // Enable UAV (unordered access view)
        depthTexture.Create();

        targetRawImage.texture = resultTexture;
        PrepareMeshData();
    }

    void PrepareMeshData() {
        // Combine all mesh data (vertex positions, indices, etc.)
        int totalVertexCount = 0;
        int totalIndexCount = 0;

        foreach (var mesh in meshes) {
            totalVertexCount += mesh.vertexCount;
            totalIndexCount += mesh.triangles.Length;
        }

        // Create buffers
        meshDataBuffer = new ComputeBuffer(meshes.Length,sizeof(uint) * 4);
        instanceBuffer = new ComputeBuffer(meshInstanceObjects.Length,sizeof(int) + sizeof(float) * 10);
        vertexBuffer = new ComputeBuffer(totalVertexCount, sizeof(float) * 3); // 3 floats per vertex (x, y, z)
        indexBuffer = new ComputeBuffer(totalIndexCount, sizeof(int)); // Integer indices for the mesh triangles
        Vector3[] allVertices = new Vector3[totalVertexCount];
        int[] allIndices = new int[totalIndexCount];

        int vertexOffset = 0;
        int indexOffset = 0;
        List<MeshData> meshDataList = new List<MeshData>();

        // Fill the arrays with mesh data
        foreach (var mesh in meshes) {
            MeshData meshData = new MeshData {
                vertexStart = (uint)vertexOffset,
                vertexCount = (uint)mesh.vertices.Length,
                indexStart = (uint)indexOffset,
                indexCount = (uint)totalIndexCount
            };
            meshDataList.Add(meshData);

            // Get the vertices of the current mesh and store them in the allVertices array
            Vector3[] vertices = mesh.vertices; // This is the correct way to get mesh vertices
            System.Array.Copy(vertices, 0, allVertices, vertexOffset, vertices.Length);

            // Get the indices of the current mesh and store them in the allIndices array
            int[] indices = mesh.GetIndices(0); // This returns the indices for the mesh
            System.Array.Copy(indices, 0, allIndices, indexOffset, indices.Length);

            // Update the offsets for the next mesh
            vertexOffset += vertices.Length;
            indexOffset += indices.Length;
        }

        meshInstances = new MeshInstanceData[meshInstanceObjects.Length];
        for (int i=0;i<meshInstanceObjects.Length;i++) {
            if (meshInstanceObjects[i].name.Contains("med1_7")
                && !meshInstanceObjects[i].name.Contains("med1_7d")) { meshInstances[i].meshIndex = 0;
            } else if (meshInstanceObjects[i].name.Contains("med1_7d")) { meshInstances[i].meshIndex = 1;
            } else if (meshInstanceObjects[i].name.Contains("med2_1")) { meshInstances[i].meshIndex = 2; }

            meshInstances[i].position = meshInstanceObjects[i].transform.position;
            meshInstances[i].rotation = new Vector4(meshInstanceObjects[i].transform.rotation.x,
                                                    meshInstanceObjects[i].transform.rotation.y,
                                                    meshInstanceObjects[i].transform.rotation.z,
                                                    meshInstanceObjects[i].transform.rotation.w);

            meshInstances[i].scale = meshInstanceObjects[i].transform.localScale;

        }

        meshDataBuffer.SetData(meshDataList);
        instanceBuffer.SetData(meshInstances);
        vertexBuffer.SetData(allVertices);  // Upload the vertex data to the compute buffer
        indexBuffer.SetData(allIndices);    // Upload the index data to the compute buffer


        // Set the buffers to the compute shader
        int kernel = firstPassShader.FindKernel("CSMain");
        firstPassShader.SetBuffer(kernel, "meshDataBuffer", meshDataBuffer);
        firstPassShader.SetBuffer(kernel, "instanceData", instanceBuffer);
        firstPassShader.SetBuffer(kernel, "vertices", vertexBuffer);
        firstPassShader.SetBuffer(kernel, "indices", indexBuffer);
    }

    void Update() {
        int kernel = firstPassShader.FindKernel("CSMain");
        firstPassShader.SetTexture(kernel, "Result", resultTexture);
        firstPassShader.SetTexture(kernel, "DepthBuffer", depthTexture);
        int threadGroupsX = Mathf.CeilToInt(resultTexture.width / 32.0f);
        int threadGroupsY = Mathf.CeilToInt(resultTexture.height / 32.0f);
        firstPassShader.Dispatch(kernel, threadGroupsX, threadGroupsY, 1);
    }

    void OnDestroy() {
        if (meshDataBuffer != null) meshDataBuffer.Release();
        if (instanceBuffer != null) instanceBuffer.Release();
        if (vertexBuffer != null) vertexBuffer.Release();
        if (indexBuffer != null) indexBuffer.Release();
    }
}
