using UnityEngine;
using Unity.Jobs;
using Unity.Burst;
using Unity.Collections;
using System.Collections.Generic;
using System.Diagnostics;

public class CitadelLightMapper : MonoBehaviour {
    public MeshRenderer[] targetRenderers; // Array of MeshRenderers to apply lightmaps to
    public Mesh[] meshes; // Each kind of mesh
    public Light[] lights;
    public Texture2D[] results;
    public int lightmapWidth = 32;
    public int debugIndex = 0;

    private LightmapData[] newLightmaps;
    private bool bakeDone = false;
    private float lightFac = 0.2f;
    private float lightPow = 1.2f;
    private NativeArray<Color> bakedTextureColors;
    private NativeArray<Vector3> cardPositions;
    private NativeArray<Vector3> cardForwards;
    private NativeArray<Vector3> cardUps;
    private NativeArray<Vector3> cardRights;
    private NativeArray<Vector3> lightPositions;
    private NativeArray<float> lightRanges;
    private NativeArray<Color> lightColors;
    private NativeArray<float> lightIntensities;
    private NativeArray<Triangle> triangles;
    private JobHandle currentJobHandle;
    private Stopwatch bakeTimer;

    public static CitadelLightMapper a;

    void Start() {
        a = this;

        // Create new buffers
        cardPositions = new NativeArray<Vector3>(targetRenderers.Length, Allocator.Persistent);
        cardForwards = new NativeArray<Vector3>(targetRenderers.Length, Allocator.Persistent);
        cardUps = new NativeArray<Vector3>(targetRenderers.Length, Allocator.Persistent);
        cardRights = new NativeArray<Vector3>(targetRenderers.Length, Allocator.Persistent);
        bakedTextureColors = new NativeArray<Color>(targetRenderers.Length * lightmapWidth * lightmapWidth, Allocator.Persistent);
        lightPositions = new NativeArray<Vector3>(lights.Length, Allocator.Persistent);
        lightRanges = new NativeArray<float>(lights.Length, Allocator.Persistent);
        lightColors = new NativeArray<Color>(lights.Length, Allocator.Persistent);
        lightIntensities = new NativeArray<float>(lights.Length, Allocator.Persistent);
        results = new Texture2D[targetRenderers.Length];
        List<Triangle> gotTris = new List<Triangle>();
        Mesh msh;
        PrefabIdentifier pid;
        Matrix4x4 localToWorld;
        Vector3[] vertices;
        Vector3[] normals;
        Color[] colors;
        Vector2[] uvs;
        Vector4[] tangents;
        int[] tris;
        Vector3 posA,posB,posC,normA,normB,normC;

        // Populate buffers
        for (int i=0;i<targetRenderers.Length;i++) {
            cardPositions[i] = targetRenderers[i].transform.position;
            cardForwards[i] = targetRenderers[i].transform.forward;
            cardUps[i] = targetRenderers[i].transform.up;
            cardRights[i] = targetRenderers[i].transform.right;
            pid = targetRenderers[i].gameObject.GetComponent<PrefabIdentifier>();
            if (pid == null) continue;

            int idx = 0;
            if (pid.constIndex == 178) idx = 0; // med2_1
            else if (pid.constIndex == 162) idx = 1; // med1_7
            else if (pid.constIndex == 167) idx = 2; // med1_7d
            msh = meshes[idx];

            // Get mesh data
            vertices = msh.vertices;
            normals = msh.normals;
            colors = msh.colors;
            uvs = msh.uv;
            tangents = msh.tangents;
            tris = msh.triangles;

            // Transform data into world space and create Triangle structs
            localToWorld = targetRenderers[i].transform.localToWorldMatrix;

            for (int j = 0; j < tris.Length; j += 3) {
                // Get indices of the vertices of the triangle
                int idxA = tris[j];
                int idxB = tris[j + 1];
                int idxC = tris[j + 2];

                // Transform positions to world space
                posA = localToWorld.MultiplyPoint3x4(vertices[idxA]);
                posB = localToWorld.MultiplyPoint3x4(vertices[idxB]);
                posC = localToWorld.MultiplyPoint3x4(vertices[idxC]);

                // Transform normals to world space
                normA = localToWorld.MultiplyVector(normals[idxA]);
                normB = localToWorld.MultiplyVector(normals[idxB]);
                normC = localToWorld.MultiplyVector(normals[idxC]);

                // Create Triangle struct
                Triangle tri = new Triangle {
                    posA = posA,
                    posB = posB,
                    posC = posC,
                    normA = normA.normalized,
                    normB = normB.normalized,
                    normC = normC.normalized,
                    color = colors.Length > 0 ? colors[idxA] : Color.white,
                    uvA = uvs.Length > 0 ? uvs[idxA] : Vector2.zero,
                    uvB = uvs.Length > 0 ? uvs[idxB] : Vector2.zero,
                    uvC = uvs.Length > 0 ? uvs[idxC] : Vector2.zero,
                    tanA = tangents.Length > 0 ? tangents[idxA] : Vector4.zero,
                    tanB = tangents.Length > 0 ? tangents[idxB] : Vector4.zero,
                    tanC = tangents.Length > 0 ? tangents[idxC] : Vector4.zero,
                    meshRendererIndex = i
                };

                // Add to list
                gotTris.Add(tri);
            }
        }

        triangles = new NativeArray<Triangle>(gotTris.Count, Allocator.Persistent);
        for (int i=0;i<triangles.Length;i++) triangles[i] = gotTris[i];
        for (int i=0;i<(targetRenderers.Length * lightmapWidth * lightmapWidth);i++) bakedTextureColors[i] = Color.black;
        for (int i=0;i<lights.Length;i++) {
            lightPositions[i] = lights[i].transform.position;
            lightRanges[i] = lights[i].range;
            lightColors[i] = lights[i].color;
            lightIntensities[i] = lights[i].intensity;
        }

        LightmapSettings.lightmapsMode = LightmapsMode.NonDirectional;
        newLightmaps = new LightmapData[targetRenderers.Length];

        //for(int index=0;index < cardPositions.Length;index++) {
        int index = 0;
         if (index > cardPositions.Length) return; // Nothing more to do

            int baseIndex = index * lightmapWidth * lightmapWidth;
            float atten = 0f;
            float distanceSquared = 0f;
            int colorsIndex = 0;
            bool breakout = false;
            Color pencil;
            Vector3 dir,hitPos;
            
            // Iterate over all texels for this geometry chunk card.
            for (int y=0;y<lightmapWidth;y++) {
                for (int x=0;x<lightmapWidth;x++) {
                    hitPos = GetTexelWorldPosition(cardPositions[index],x,y,cardForwards[index],cardRights[index],cardUps[index]); // Get Texel World Position
                    
                    // Iterate over all lights for this texel
                    for (int lightIndex=0;lightIndex<lightPositions.Length;lightIndex++) {
                        dir = hitPos - lightPositions[lightIndex];
                        distanceSquared = dir.sqrMagnitude;
                        dir = dir.normalized;
                        colorsIndex = (index * lightmapWidth * lightmapWidth) + ((y * lightmapWidth) + x);
                        if (colorsIndex >= bakedTextureColors.Length) { breakout = true; break; }

                        TriangleHitInfo triHitInfo = new TriangleHitInfo { hitPoint = Vector3.zero, normal = Vector3.zero, meshRendererIndex = -1, didHit = false }; 
                        bool inShadow = false;
                        for (int i=0;i<triangles.Length;i++) {
                            triHitInfo = RayTriangle(lightPositions[lightIndex],dir,triangles[i]);
                            if (triHitInfo.didHit) {
                                if ((lightPositions[lightIndex] - triHitInfo.hitPoint).sqrMagnitude < distanceSquared) {
                                    inShadow = true;
                                    break;
                                }
                                
                                if (triHitInfo.meshRendererIndex == index) break; // Success, we hit our target.
                            }
                        }
                        
                        if (inShadow) break; // Nothing more to be done for this light.
                        
                        atten = GetLighting(lightPositions[lightIndex],hitPos,-cardUps[index],lightRanges[lightIndex],lightIntensities[lightIndex]);
                        pencil = new Color(atten * lightColors[lightIndex].r,atten * lightColors[lightIndex].g,atten * lightColors[lightIndex].b,1f);
                        bakedTextureColors[colorsIndex] += pencil;
                    }
                }

                if (breakout) break;
            }
        //}
        bakeTimer = new Stopwatch();
//         BakeLightJob bakeJob = new BakeLightJob {
//             lightPositions = lightPositions,
//             lightRanges = lightRanges,
//             cardPositions = cardPositions,
//             cardForwards = cardForwards,
//             cardUps = cardUps,
//             cardRights = cardRights,
//             triangles = triangles,
//             bakedTextureColors = bakedTextureColors,
//             lightColors = lightColors,
//             lightIntensities = lightIntensities,
//             lightmapWidth = lightmapWidth
//         };
// 
        bakeTimer.Start();
//         currentJobHandle = bakeJob.Schedule(targetRenderers.Length,targetRenderers.Length / 10);
    }

    void Update() {
        if (!bakeDone) {
            if (currentJobHandle.IsCompleted) {
                currentJobHandle.Complete();
                bakeTimer.Stop();
                UnityEngine.Debug.Log("Parallel bake completed in: " + bakeTimer.Elapsed.ToString());
                bakeTimer.Restart();
                ApplyFinishedJobResults();
                bakeDone = true;
                bakeTimer.Stop();
                UnityEngine.Debug.Log("Applied bake in: " + bakeTimer.Elapsed.ToString());
            }
        }
    }

    private void ApplyUniqueLightmap(int index) {
        Texture2D tex = new Texture2D(lightmapWidth,lightmapWidth);
        tex.wrapMode = TextureWrapMode.Clamp;
        tex.filterMode = FilterMode.Trilinear;
        Color[] cols = new Color[lightmapWidth * lightmapWidth];
        for (int i=0;i<cols.Length;i++) cols[i] = bakedTextureColors[(index * lightmapWidth * lightmapWidth) + i];
        tex.SetPixels(cols);
        tex.Apply();
        results[index] = tex;
        newLightmaps[index] = new LightmapData();
        newLightmaps[index].lightmapColor = tex;
        targetRenderers[index].lightmapIndex = index;
        targetRenderers[index].lightmapScaleOffset = new Vector4(1, 1, 0, 0); // Full coverage
    }

    private void ApplyFinishedJobResults() {
        for (int k=0;k<targetRenderers.Length;k++) ApplyUniqueLightmap(k);
        for (int k=0;k<lights.Length;k++) {
            lights[k].cullingMask &= ~(1 << 9); // Remove Geometry layer so light doesn't affect baked meshRenderers.
        }

        LightmapSettings.lightmaps = newLightmaps; // Finally put actual lightmaps into use.
    }

    private struct BakeLightJob : IJobParallelFor {
        [ReadOnly] public NativeArray<Vector3> lightPositions;
        [ReadOnly] public NativeArray<float> lightRanges;
        [ReadOnly] public NativeArray<Color> lightColors;
        [ReadOnly] public NativeArray<float> lightIntensities;
        [ReadOnly] public NativeArray<Vector3> cardPositions;
        [ReadOnly] public NativeArray<Vector3> cardForwards;
        [ReadOnly] public NativeArray<Vector3> cardUps;
        [ReadOnly] public NativeArray<Vector3> cardRights;
        [ReadOnly] public NativeArray<Triangle> triangles;
        [ReadOnly] public int lightmapWidth;
        [NativeDisableParallelForRestriction] public NativeArray<Color> bakedTextureColors;

        public void Execute(int index) {
            if (index > cardPositions.Length) return; // Nothing more to do

            int baseIndex = index * lightmapWidth * lightmapWidth;
            float atten = 0f;
            float distanceSquared = 0f;
            int colorsIndex = 0;
            bool breakout = false;
            Color pencil;
            Vector3 dir,hitPos;
            
            // Iterate over all texels for this geometry chunk card.
            for (int y=0;y<lightmapWidth;y++) {
                for (int x=0;x<lightmapWidth;x++) {
                    hitPos = GetTexelWorldPosition(cardPositions[index],x,y,cardForwards[index],cardRights[index],cardUps[index]); // Get Texel World Position
                    
                    // Iterate over all lights for this texel
                    for (int lightIndex=0;lightIndex<lightPositions.Length;lightIndex++) {
                        dir = hitPos - lightPositions[lightIndex];
                        distanceSquared = dir.sqrMagnitude;
                        dir = dir.normalized;
                        colorsIndex = (index * lightmapWidth * lightmapWidth) + ((y * lightmapWidth) + x);
                        if (colorsIndex >= bakedTextureColors.Length) { breakout = true; break; }

                        TriangleHitInfo triHitInfo = new TriangleHitInfo { hitPoint = Vector3.zero, normal = Vector3.zero, meshRendererIndex = -1, didHit = false }; 
                        bool inShadow = false;
                        for (int i=0;i<triangles.Length;i++) {
                            triHitInfo = RayTriangle(lightPositions[lightIndex],dir,triangles[i]);
                            if (triHitInfo.didHit) {
                                if ((lightPositions[lightIndex] - triHitInfo.hitPoint).sqrMagnitude < distanceSquared) {
                                    inShadow = true;
                                    break;
                                }
                                
                                if (triHitInfo.meshRendererIndex == index) break; // Success, we hit our target.
                            }
                        }
                        
                        if (inShadow) break; // Nothing more to be done for this light.
                        
                        atten = GetLighting(lightPositions[lightIndex],hitPos,-cardUps[index],lightRanges[lightIndex],lightIntensities[lightIndex]);
                        pencil = new Color(atten * lightColors[lightIndex].r,atten * lightColors[lightIndex].g,atten * lightColors[lightIndex].b,1f);
                        bakedTextureColors[colorsIndex] += pencil;
                    }
                }

                if (breakout) break;
            }
        }
    }
    
    private static Vector3 GetTexelWorldPosition(Vector3 cardCenter, int x, int y, Vector3 forward, Vector3 right, Vector3 up) {
        // Map x: 0 -> cardWidth/2, 31 -> -cardWidth/2
        float localX = Mathf.Lerp(1.26f, -1.26f, (float)x / ((float)a.lightmapWidth - 1f));
        // Map y: 0 -> cardHeight/2, 31 -> -cardHeight/2
        float localY = Mathf.Lerp(-1.26f, 1.26f, (float)y / ((float)a.lightmapWidth - 1f));

        // Calculate world position using cardCenter and orientation vectors
        Vector3 worldPosition = cardCenter + (right * localX) + (up * 1.28f) + (forward * localY); // Front surface
        return worldPosition;
    }

    private static float GetLighting(Vector3 lightPos, Vector3 hitPos, Vector3 triNorm, float range, float intensity) {
        float atten = 0f;
//         float lambert = 1f;
        Vector3 dir = lightPos - hitPos;
        float distanceSquared = dir.sqrMagnitude;
        if (distanceSquared <= (range * range)) atten = 1f - (distanceSquared / (range * range));

        //lambert = Mathf.Max(0.0f,Vector3.Dot(triNorm,Vector3.Normalize(dir)));
        //atten *= lambert;
        atten *= intensity * a.lightFac;
        atten = Mathf.Max(0.0f,Mathf.Pow(atten,a.lightPow));
        return atten;
    }

    void OnDestroy() {
        if (currentJobHandle.IsCompleted == false) currentJobHandle.Complete();
        if (lightPositions != null) { if (lightPositions.IsCreated) lightPositions.Dispose(); }
        if (lightRanges != null) { if (lightRanges.IsCreated) lightRanges.Dispose(); }
        if (cardPositions != null) { if (cardPositions.IsCreated) cardPositions.Dispose(); }
        if (cardForwards != null) { if (cardForwards.IsCreated) cardForwards.Dispose(); }
        if (cardUps != null) { if (cardUps.IsCreated) cardUps.Dispose(); }
        if (cardRights != null) { if (cardRights.IsCreated) cardRights.Dispose(); }
        if (bakedTextureColors != null) { if (bakedTextureColors.IsCreated) bakedTextureColors.Dispose(); }
        if (lightColors != null) { if (lightColors.IsCreated) lightColors.Dispose(); }
        if (lightIntensities != null) { if (lightIntensities.IsCreated) lightIntensities.Dispose(); }
        if (triangles != null) { if (triangles.IsCreated) triangles.Dispose(); }
    }

    private struct Triangle {
        public Vector3 posA, posB, posC;
        public Vector3 normA, normB, normC;
        public Color color;
        public Vector2 uvA, uvB, uvC;
        public Vector4 tanA, tanB, tanC;
        public int meshRendererIndex;
    };

    private struct TriangleHitInfo {
        public Vector3 hitPoint;
        public Vector3 normal;
        public int meshRendererIndex;
        public bool didHit;
    };

    // Calculate the intersection of a ray with a triangle using MöllerTrumbore algorithm
    // Thanks to https://stackoverflow.com/a/42752998
    private static TriangleHitInfo RayTriangle(Vector3 origin, Vector3 dir, Triangle tri) {
        TriangleHitInfo hitInfo;
        hitInfo.didHit = false;
        hitInfo.hitPoint = hitInfo.normal = Vector3.zero;
        hitInfo.meshRendererIndex = -1;
        Vector3 edgeAB = tri.posB - tri.posA;
        Vector3 edgeAC = tri.posC - tri.posA;
        Vector3 normalVector = Vector3.Cross(edgeAB, edgeAC);
        Vector3 ao = origin - tri.posA;
        Vector3 dao = Vector3.Cross(ao,dir);

        float determinant = -Vector3.Dot(dir, normalVector);
        float invDet = 1 / determinant;
        if (!(determinant >= 1E-4)) return hitInfo;

        // Calculate dst to triangle & barycentric coordinates of intersection point
        float dst = Vector3.Dot(ao, normalVector) * invDet;
        float u = Vector3.Dot(edgeAC, dao) * invDet;
        float v = -Vector3.Dot(edgeAB, dao) * invDet;
        float w = 1 - u - v;

        // Initialize hit info
        hitInfo.didHit = dst >= 0 && u >= 0 && v >= 0 && w >= 0;
        hitInfo.hitPoint = origin + dir * dst;
        hitInfo.meshRendererIndex = tri.meshRendererIndex;
        hitInfo.normal = tri.normA;
        return hitInfo;
    }
}



// Per Triangle method:
// using UnityEngine;
// using Unity.Jobs;
// using Unity.Burst;
// using Unity.Collections;
// using System.Collections.Generic;
// using System.Diagnostics;
// 
// public class CitadelLightMapper : MonoBehaviour {
//     public MeshRenderer[] targetRenderers; // Array of MeshRenderers to apply lightmaps to
//     public Mesh[] meshes; // Each kind of mesh
//     public Light[] lights;
//     public Texture2D[] results;
//     public int lightmapWidth = 32;
//     
//     private LightmapData[] newLightmaps;
//     private bool bakeDone = false;
//     private float lightFac = 0.2f;
//     private float lightPow = 1.2f;
//     private NativeArray<Color> bakedTextureColors;
//     private NativeArray<bool> bakedDone;
//     private NativeArray<Vector3> lightPositions;
//     private NativeArray<float> lightRanges;
//     private NativeArray<Color> lightColors;
//     private NativeArray<float> lightIntensities;
//     private NativeArray<Triangle> triangles;
//     private JobHandle currentJobHandle;
//     private Stopwatch bakeTimer;
//     
//     public static CitadelLightMapper a;
// 
//     void Start() {
//         a = this;
// 
//         // Create new buffers
//         bakedTextureColors = new NativeArray<Color>(targetRenderers.Length * lightmapWidth * lightmapWidth, Allocator.Persistent);
//         bakedDone = new NativeArray<bool>(targetRenderers.Length * lightmapWidth * lightmapWidth, Allocator.Persistent);
//         lightPositions = new NativeArray<Vector3>(lights.Length, Allocator.Persistent);
//         lightRanges = new NativeArray<float>(lights.Length, Allocator.Persistent);
//         lightColors = new NativeArray<Color>(lights.Length, Allocator.Persistent);
//         lightIntensities = new NativeArray<float>(lights.Length, Allocator.Persistent);
//         results = new Texture2D[targetRenderers.Length];
//         List<Triangle> gotTris = new List<Triangle>();
//         Mesh msh;
//         PrefabIdentifier pid;
//         Matrix4x4 localToWorld;
//         Vector3[] vertices;
//         Vector3[] normals;
//         Color[] colors;
//         Vector2[] uvs;
//         Vector2[] uvs2;
//         Vector4[] tangents;
//         int[] tris;
//         Vector3 posA,posB,posC,normA,normB,normC;
// 
//         // Populate buffers
//         for (int i=0;i<targetRenderers.Length;i++) {
//             pid = targetRenderers[i].gameObject.GetComponent<PrefabIdentifier>();
//             if (pid == null) continue;
// 
//             int idx = 0;
//             if (pid.constIndex == 178) idx = 0; // med2_1
//             else if (pid.constIndex == 162) idx = 1; // med1_7
//             else if (pid.constIndex == 167) idx = 2; // med1_7d
//             msh = meshes[idx];
// 
//             // Get mesh data
//             vertices = msh.vertices;
//             normals = msh.normals;
//             colors = msh.colors;
//             uvs = msh.uv;
//             uvs2 = msh.uv2;
//             if (uvs2.Length < 1) uvs2 = uvs;
//             tangents = msh.tangents;
//             tris = msh.triangles;
// 
//             // Transform data into world space and create Triangle structs
//             localToWorld = targetRenderers[i].transform.localToWorldMatrix;
// 
//             for (int j = 0; j < tris.Length; j += 3) {
//                 // Get indices of the vertices of the triangle
//                 int idxA = tris[j];
//                 int idxB = tris[j + 1];
//                 int idxC = tris[j + 2];
// 
//                 // Transform positions to world space
//                 posA = localToWorld.MultiplyPoint3x4(vertices[idxA]);
//                 posB = localToWorld.MultiplyPoint3x4(vertices[idxB]);
//                 posC = localToWorld.MultiplyPoint3x4(vertices[idxC]);
// 
//                 // Transform normals to world space
//                 normA = localToWorld.MultiplyVector(normals[idxA]);
//                 normB = localToWorld.MultiplyVector(normals[idxB]);
//                 normC = localToWorld.MultiplyVector(normals[idxC]);
// 
//                 // Create Triangle struct
//                 Triangle tri = new Triangle {
//                     posA = posA,
//                     posB = posB,
//                     posC = posC,
//                     normA = normA.normalized,
//                     normB = normB.normalized,
//                     normC = normC.normalized,
//                     color = colors.Length > 0 ? colors[idxA] : Color.white,
//                     uvA = uvs.Length > 0 ? uvs[idxA] : Vector2.zero,
//                     uvB = uvs.Length > 0 ? uvs[idxB] : Vector2.zero,
//                     uvC = uvs.Length > 0 ? uvs[idxC] : Vector2.zero,
//                     uv2A= uvs2.Length > 0 ? uvs2[idxA] : Vector2.zero,
//                     uv2B= uvs2.Length > 0 ? uvs2[idxB] : Vector2.zero,
//                     uv2C= uvs2.Length > 0 ? uvs2[idxC] : Vector2.zero,
//                     tanA = tangents.Length > 0 ? tangents[idxA] : Vector4.zero,
//                     tanB = tangents.Length > 0 ? tangents[idxB] : Vector4.zero,
//                     tanC = tangents.Length > 0 ? tangents[idxC] : Vector4.zero,
//                     meshRendererIndex = i
//                 };
// 
//                 // Add to list
//                 gotTris.Add(tri);
//             }
//         }
// 
//         triangles = new NativeArray<Triangle>(gotTris.Count, Allocator.Persistent);
//         for (int i=0;i<triangles.Length;i++) triangles[i] = gotTris[i];
//         for (int i=0;i<(targetRenderers.Length * lightmapWidth * lightmapWidth);i++) {
//             bakedTextureColors[i] = Color.black;
//             bakedDone[i] = false;
//         }
//         
//         for (int i=0;i<lights.Length;i++) {
//             lightPositions[i] = lights[i].transform.position;
//             lightRanges[i] = lights[i].range;
//             lightColors[i] = lights[i].color;
//             lightIntensities[i] = lights[i].intensity;
//         }
// 
//         UnityEngine.Debug.Log("Num tris: " + triangles.Length.ToString() + ", Num Lights; " + lights.Length.ToString());
//         LightmapSettings.lightmapsMode = LightmapsMode.NonDirectional;
//         newLightmaps = new LightmapData[targetRenderers.Length];
// 
//         bakeTimer = new Stopwatch();
//         
//         BakeLightJob bakeJob = new BakeLightJob {
//             lightPositions = lightPositions,
//             lightRanges = lightRanges,
//             triangles = triangles,
//             bakedTextureColors = bakedTextureColors,
//             bakedDone = bakedDone,
//             lightColors = lightColors,
//             lightIntensities = lightIntensities,
//             lightmapWidth = lightmapWidth
//         };
// 
//         bakeTimer.Start();
//         currentJobHandle = bakeJob.Schedule(triangles.Length,triangles.Length / 10);
//     }
// 
//     void Update() {
//         if (!bakeDone) {
//             if (currentJobHandle.IsCompleted) {
//                 currentJobHandle.Complete();
//                 bakeTimer.Stop();
//                 UnityEngine.Debug.Log("Parallel bake completed in: " + bakeTimer.Elapsed.ToString());
//                 bakeTimer.Restart();
//                 ApplyFinishedJobResults();
//                 bakeDone = true;
//                 bakeTimer.Stop();
//                 UnityEngine.Debug.Log("Applied bake in: " + bakeTimer.Elapsed.ToString());
//             }
//         }
//     }
// 
//     private void ApplyUniqueLightmap(int index) {
//         Texture2D tex = new Texture2D(lightmapWidth,lightmapWidth);
//         tex.wrapMode = TextureWrapMode.Clamp;
//         tex.filterMode = FilterMode.Trilinear;
//         Color[] cols = new Color[lightmapWidth * lightmapWidth];
//         int pixelIndex;
//         for (int i=0;i<cols.Length;i++) {
//             pixelIndex = index * (lightmapWidth * lightmapWidth) + i;//(y * lightmapWidth) + x; This is the inverse, here we sample flatly so just i.
//             cols[i] = bakedTextureColors[pixelIndex];
//         }
//         tex.SetPixels(cols);
//         tex.Apply();
//         results[index] = tex;
//         newLightmaps[index] = new LightmapData();
//         newLightmaps[index].lightmapColor = tex;
//         targetRenderers[index].lightmapIndex = index;
//         targetRenderers[index].lightmapScaleOffset = new Vector4(1, 1, 0, 0); // Full coverage
//     }
// 
//     private void ApplyFinishedJobResults() {
//         for (int k=0;k<targetRenderers.Length;k++) ApplyUniqueLightmap(k);
//         for (int k=0;k<lights.Length;k++) {
//             lights[k].cullingMask &= ~(1 << 9); // Remove Geometry layer so light doesn't affect baked meshRenderers.
//         }
// 
//         LightmapSettings.lightmaps = newLightmaps; // Finally put actual lightmaps into use.
//     }
//     
//     private struct Triangle {
//         public Vector3 posA, posB, posC;
//         public Vector3 normA, normB, normC;
//         public Color color;
//         public Vector2 uvA, uvB, uvC;
//         public Vector2 uv2A, uv2B, uv2C; // Lightmap UVs
//         public Vector4 tanA, tanB, tanC;
//         public int meshRendererIndex;
//     };
// 
//     private struct TriangleHitInfo {
//         public bool didHit;
//         public Vector3 hitPoint;
//     };
// 
//     private struct BakeLightJob : IJobParallelFor {
//         [ReadOnly] public NativeArray<Vector3> lightPositions;
//         [ReadOnly] public NativeArray<float> lightRanges;
//         [ReadOnly] public NativeArray<Color> lightColors;
//         [ReadOnly] public NativeArray<float> lightIntensities;
//         [ReadOnly] public NativeArray<Triangle> triangles;
//         [ReadOnly] public int lightmapWidth;
//         [NativeDisableParallelForRestriction] public NativeArray<Color> bakedTextureColors;
//         [NativeDisableParallelForRestriction] public NativeArray<bool> bakedDone;
// 
//         public void Execute(int index) {
//             if (index > triangles.Length) return; // Nothing more to do
// 
//             // Iterate over all triangles
//             // Get the lightmap uv min and max coordinates
//             // Iterate over all lightmap texels on the triangle
//             // Trace rays to each light from each texel
//             // Bake lighting into the texel value
//             float atten = 0f;
//             TriangleHitInfo triHitInfo;
//             Vector3 rayOrigin, barycentric, worldPos, rayDir;
//             Vector2 uv2A, uv2B, uv2C, currentUV;
//             float minx,miny,maxx,maxy;
//             int pixelIndex;
//             Color pencil;
//             uv2A = triangles[index].uv2A;
//             uv2B = triangles[index].uv2B;
//             uv2C = triangles[index].uv2C;
//             minx = Mathf.Min(uv2A.x,Mathf.Min(uv2B.x,uv2C.x)) * lightmapWidth;
//             miny = Mathf.Min(uv2A.y,Mathf.Min(uv2B.y,uv2C.y)) * lightmapWidth;
//             maxx = Mathf.Max(uv2A.x,Mathf.Max(uv2B.x,uv2C.x)) * lightmapWidth;
//             maxy = Mathf.Max(uv2A.y,Mathf.Max(uv2B.y,uv2C.y)) * lightmapWidth;
//             for (float y=miny;y<maxy;y++) {
//                 for (float x=minx;x<maxx;x++) {
//                     int pixelX = Mathf.FloorToInt(x);
//                     int pixelY = Mathf.FloorToInt(y);
//                     pixelIndex = triangles[index].meshRendererIndex * (lightmapWidth * lightmapWidth) + (pixelY * lightmapWidth) + pixelX;
//                     if (bakedDone[pixelIndex]) continue; // Already ran traces on this texel.
//                     
//                     currentUV.x = x / (float)lightmapWidth;
//                     currentUV.y = y / (float)lightmapWidth; // Convert back to UV space
//                     barycentric = CalculateBarycentric(currentUV, uv2A, uv2B, uv2C);
//                     worldPos = InterpolateWorldPosition(barycentric, triangles[index]);
//                     for (int lightIndex=0;lightIndex<lightPositions.Length;lightIndex++) {
//                         rayOrigin = lightPositions[lightIndex];
//                         rayDir = Vector3.Normalize(worldPos - rayOrigin);
//                         triHitInfo = RayTriangle(rayOrigin,rayDir,triangles[index]);
//                         if (!triHitInfo.didHit) continue;
//                         if (Vector3.Distance(triHitInfo.hitPoint,worldPos) > 0.02f) continue;
//                         
//                         atten = GetLighting(rayOrigin,triHitInfo.hitPoint,triangles[index].normA,lightRanges[lightIndex],lightIntensities[lightIndex]);
//                         pencil = new Color((atten * lightColors[lightIndex].r) + bakedTextureColors[pixelIndex].r,
//                                             (atten * lightColors[lightIndex].g) + bakedTextureColors[pixelIndex].g,
//                                             (atten * lightColors[lightIndex].b) + bakedTextureColors[pixelIndex].b,1);
//                         
//                         bakedTextureColors[pixelIndex] = pencil;
//                     }
//                     
//                     bakedDone[pixelIndex] = true; // Texel baked
//                 }
//             }
//         }
//     
//         private Vector3 CalculateBarycentric(Vector2 point, Vector2 v1, Vector2 v2, Vector2 v3) {
//             Vector2 v21 = v2 - v1;
//             Vector2 v31 = v3 - v1;
//             Vector2 point1 = point - v1;
//             float denom = v21.x * v31.y - v31.x * v21.y;
//             float v = (point1.x * v31.y - v31.x * point1.y) / denom;
//             float w = (v21.x * point1.y - point1.x * v21.y) / denom;
//             float u = 1.0f - v - w;
//             return new Vector3(u, v, w);
//         }
// 
//         private Vector3 InterpolateWorldPosition(Vector3 barycentric, Triangle tri) {
//             return barycentric.x * tri.posA + barycentric.y * tri.posB + barycentric.z * tri.posC;
//         }
// 
//         private Vector3 InterpolateNormal(Vector3 barycentric, Triangle tri) {
//             return (barycentric.x * tri.normA + barycentric.y * tri.normB + barycentric.z * tri.normC).normalized;
//         }
// 
//         private static float GetLighting(Vector3 lightPos, Vector3 hitPos, Vector3 triNorm, float range, float intensity) {
//             float atten = 0f;
//             float lambert = 1f;
//             Vector3 dir = lightPos - hitPos;
//             float distanceSquared = dir.sqrMagnitude;
//             if (distanceSquared <= (range * range)) atten = 1f - (distanceSquared / (range * range));
// 
//             lambert = Mathf.Max(0.0f,Vector3.Dot(triNorm,Vector3.Normalize(dir)));
//             atten *= lambert;
//             atten *= intensity * a.lightFac;
//             atten = Mathf.Max(0.0f,Mathf.Pow(atten,a.lightPow));
//             return atten;
//         }
//     }
// 
//     void OnDestroy() {
//         if (currentJobHandle.IsCompleted == false) currentJobHandle.Complete();
//         if (lightPositions != null) { if (lightPositions.IsCreated) lightPositions.Dispose(); }
//         if (lightRanges != null) { if (lightRanges.IsCreated) lightRanges.Dispose(); }
//         if (bakedTextureColors != null) { if (bakedTextureColors.IsCreated) bakedTextureColors.Dispose(); }
//         if (lightColors != null) { if (lightColors.IsCreated) lightColors.Dispose(); }
//         if (lightIntensities != null) { if (lightIntensities.IsCreated) lightIntensities.Dispose(); }
//         if (triangles != null) { if (triangles.IsCreated) triangles.Dispose(); }
//     }
// 
//     // Calculate the intersection of a ray with a triangle using MöllerTrumbore algorithm
//     // Thanks to https://stackoverflow.com/a/42752998
//     private static TriangleHitInfo RayTriangle(Vector3 origin, Vector3 dir, Triangle tri) {
//         TriangleHitInfo hitInfo;
//         hitInfo.didHit = false;
//         hitInfo.hitPoint = Vector3.zero;
//         Vector3 edgeAB = tri.posB - tri.posA;
//         Vector3 edgeAC = tri.posC - tri.posA;
//         Vector3 normalVector = Vector3.Cross(edgeAB, edgeAC);
//         Vector3 ao = origin - tri.posA;
//         Vector3 dao = Vector3.Cross(ao,dir);
// 
//         float determinant = -Vector3.Dot(dir, normalVector);
//         float invDet = 1 / determinant;
//         if (!(determinant >= 1E-4)) return hitInfo;
// 
//         // Calculate dst to triangle & barycentric coordinates of intersection point
//         float dst = Vector3.Dot(ao, normalVector) * invDet;
//         float u = Vector3.Dot(edgeAC, dao) * invDet;
//         float v = -Vector3.Dot(edgeAB, dao) * invDet;
//         float w = 1 - u - v;
// 
//         // Initialize hit info
//         hitInfo.didHit = dst >= 0 && u >= 0 && v >= 0 && w >= 0;
//         hitInfo.hitPoint = origin + dir * dst;
//         return hitInfo;
//     }
// }
