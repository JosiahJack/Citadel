using UnityEngine;

public class Note : MonoBehaviour {
    public string note;
}
