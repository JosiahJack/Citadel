using UnityEngine;
using UnityEngine.Rendering;
using System.Collections.Generic;

public class LightTracer : MonoBehaviour {
    public ComputeShader rayTracingShader;
    public int textureWidth = 512;
    public int textureHeight = 512;
    public bool dirty = true;

    public RenderTexture equirectangularTexture;
    private Camera cam;
    private int kernelHandle;

    public void RenderLight(ComputeBuffer tris, ComputeBuffer nodes, ComputeBuffer models) {
        if (!dirty) return;

        kernelHandle = rayTracingShader.FindKernel("CSMain");
        rayTracingShader.SetBuffer(kernelHandle,"Triangles", tris);
        rayTracingShader.SetInt("triangleCount", tris.count);
//         Debug.Log("Set triangleCount on LightTracer.compute to " + tris.count.ToString());
        rayTracingShader.SetBuffer(kernelHandle,"Nodes", nodes);
//         Debug.Log("Had nodes count on LightTracer.compute to " + nodes.count.ToString());
        rayTracingShader.SetBuffer(kernelHandle,"ModelInfo", models);
        rayTracingShader.SetInt("modelCount", models.count);
//         Debug.Log("Set triangleCount on LightTracer.compute to " + models.count.ToString());

        // Initialize RenderTexture
        equirectangularTexture = new RenderTexture(textureWidth, textureHeight, 0, RenderTextureFormat.ARGBFloat);
        equirectangularTexture.enableRandomWrite = true;
        equirectangularTexture.Create();

        Light lit = GetComponent<Light>();
        // Setup compute shader
        rayTracingShader.SetInt("TextureWidth", textureWidth);
        rayTracingShader.SetInt("TextureHeight", textureHeight);
        rayTracingShader.SetVector("LightPosition", transform.position);
        rayTracingShader.SetVector("LightColor", lit.color);
        rayTracingShader.SetFloat("LightIntensity", lit.intensity);
        rayTracingShader.SetFloat("LightRange", lit.range);
        rayTracingShader.SetTexture(kernelHandle,"OutputTexture",equirectangularTexture);

        // Dispatch computation
        int threadGroupsX = Mathf.CeilToInt(textureWidth / 8.0f);
        int threadGroupsY = Mathf.CeilToInt(textureHeight / 8.0f);
        rayTracingShader.Dispatch(kernelHandle, threadGroupsX, threadGroupsY, 1);
        dirty = false;
    }

    void OnDestroy() {
        ShaderHelper.Release(equirectangularTexture);
    }
}
