using UnityEngine;

public readonly struct Triangle {
    public readonly Vector3 PosA;
    public readonly Vector3 PosB;
    public readonly Vector3 PosC;

    public readonly Vector3 NormalA;
    public readonly Vector3 NormalB;
    public readonly Vector3 NormalC;
    
    public readonly Color color;
    
    public readonly Vector2 UVA;
    public readonly Vector2 UVB;
    public readonly Vector2 UVC;
    
    public readonly Vector4 TangentA;
    public readonly Vector4 TangentB;
    public readonly Vector4 TangentC;

    public Triangle(Vector3 posA, Vector3 posB, Vector3 posC,
                    Vector3 normalA, Vector3 normalB, Vector3 normalC,
                    Color color,
                    Vector2 UVA, Vector2 UVB, Vector2 UVC,
                    Vector4 tangentA, Vector4 tangentB, Vector4 tangentC) {
        
        this.PosA = posA;
        this.PosB = posB;
        this.PosC = posC;
        this.NormalA = normalA;
        this.NormalB = normalB;
        this.NormalC = normalC;
        this.color = color;
        this.UVA = UVA;
        this.UVB = UVB;
        this.UVC = UVC;
        this.TangentA = tangentA;
        this.TangentB = tangentB;
        this.TangentC = tangentC;
    }
}
