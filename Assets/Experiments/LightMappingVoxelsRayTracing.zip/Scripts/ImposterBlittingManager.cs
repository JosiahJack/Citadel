using UnityEngine;
using System.Diagnostics;
using System.Collections.Generic;

public class ImposterBlittingManager : MonoBehaviour {
    public MeshRenderer mr;
    private Stopwatch bakeTimer;
    public Texture2DArray chunkAlbedo;
    public GameObject[] chunksToVoxelize;
    public int width = 4;
    public int voxelRenderResolution = 16;
    public int averageDivisor = 64;
    public int debugVoxelIndex = 130;
    public float lightVolumeMultiplier = 2f;
    public float voxelFOV = 150f;
    public float voxelNearZ = 0.02f;
    public float voxelFarZ = 70f;
    public float voxelVolume = 2f;
    public float voxelVolumeFOVFac = 12f;
    public List<Loxel> Voxels;
    private Dictionary<Vector3Int, Loxel> VoxelMap1 = new Dictionary<Vector3Int, Loxel>();
    private Dictionary<Vector3Int, Loxel> VoxelMap2 = new Dictionary<Vector3Int, Loxel>();
    private Dictionary<Vector3Int, Loxel> VoxelMap3 = new Dictionary<Vector3Int, Loxel>(); // Outside corners of 3 overlapping chunks can have 3 voxels in same position.
    public Light[] lights;
    public Camera voxelCam;
    public bool ambientPass1 = true;
    public bool ambientPass2 = true;
    public bool ambientPass3 = true;
    private int lightIndex = 0;
    private float voxelRenderResolutionHalf;
    private float maxDot;
    private float voxelSize;
    private float voxelSizeSquared;
    private int voxelWorldMax;
    public ComputeShader voxSubrender;
    private ComputeBuffer billboardBuffer;
    public RenderTexture resultTexture;
    private BillboardData[] billboardData;
    private VoxelToVoxelEdge[] edgeData;
    
    // Light Voxel
    public class Loxel {
        public Vector3 globalPos;
        public float size;
        public Vector3 normal;
        public Vector3 up;
        public Vector3 right;
        public Color diffuse;
        public Color directLighting;
        public Color ambientPass1;
        public Color ambientPass2;
        public Color ambientPass3;
        public Color finalLighting;
        public GameObject debugCube;
        public int chunkObjectIndex;
        public int chunkIndex;
        public int voxelIndex;
        public float spotAngle;
        public float range;
    }
    
        // Light Voxel
    public struct BillboardData {
        public Vector3 globalPos;
        public float size;
        public Vector3 normal;
        public Vector3 up;
        public Vector3 right;
        public float spotAngle;
        public float range;
        public int voxelIndex;
        public int textureIndex;
    }
    
    public class VoxelToVoxelEdge {
        public int indexA;
        public int indexB;
        public float visibilityPercent;
    }
    
    float VisibilityFraction(Vector3 positionA, Vector3 positionB, Vector3 positionC) {
        Vector3 AB = positionB - positionA;
        Vector3 AC = positionC - positionA;
        float distanceAB2 = AB.sqrMagnitude;
        float distanceAC2 = AC.sqrMagnitude;
        float threshold = (voxelSizeSquared / distanceAB2) + (voxelSizeSquared / distanceAC2);

        // Compute the dot product of normalized vectors using squared distances
        float dot = Vector3.Dot(AB, AC) / Mathf.Sqrt(distanceAB2 * distanceAC2);

        // Calculate visibility fraction
        if (dot <= threshold) {
            return 0.0f; // Not visible
        } else {
            // Linearly scale from threshold(0) to 1
            return Mathf.Clamp01((dot - threshold) / (1.0f - threshold));
        }
    }
    
    void CreateEdges() {
        List<VoxelToVoxelEdge> edges = new List<VoxelToVoxelEdge>();
        bool[] alreadyHasEdge = new bool[Voxels.Count];
        for (int a=0;a<Voxels.Count;a++) {
            if (alreadyHasEdge[a]) continue;
            
            for (int b=0;b<Voxels.Count;b++) {
                if (b == a) continue;
                if (alreadyHasEdge[b]) continue;
                
                edges[a].indexA = a;
                edges[a].indexB = b;
                alreadyHasEdge[a] = true;
                alreadyHasEdge[b] = true;
            }
        }
        
        edgeData = edges.ToArray();
    }

    void Start() {
        bakeTimer = new Stopwatch();
        bakeTimer.Start();
        voxelRenderResolutionHalf = voxelRenderResolution / 2f;
        float halfAngRadians = Mathf.Deg2Rad * (voxelFOV * 0.5f);
        maxDot = Mathf.Cos(halfAngRadians);
        voxelSize = 2.56f/width;
        voxelSizeSquared = voxelSize * voxelSize;
        voxelWorldMax = 64 * width;
        CreateVoxels();
        for (int i=0;i<lights.Length;i++) {
            Loxel lit = new Loxel();
            lit.globalPos = lights[i].transform.position;
            lit.normal = Vector3.zero;
            lit.diffuse = lights[i].color;
            lit.directLighting = new Color(lights[i].intensity,lights[i].intensity,lights[i].intensity,1f);
            lit.ambientPass1 = lit.ambientPass2 = lit.ambientPass3 = Color.black;
            lit.debugCube = MakeDebugCube(lights[i].transform,voxelSize * 0.5f,0f,0f,0f,-1,Voxels.Count);
            lit.size = voxelSize;
            SetDebugCubeColor(lit.debugCube,lights[i].color);
            lit.chunkIndex = -1;
            lit.chunkObjectIndex = -1;
            lit.voxelIndex = Voxels.Count;
            lit.up = Vector3.zero;
            lit.right = Vector3.zero;
            lit.spotAngle = lights[i].spotAngle;
            lit.range = lights[i].range;
            Voxels.Add(lit); // Add light as a voxel
            lightIndex = Voxels.Count - 1;
        }
        
        UnityEngine.Debug.Log("Total voxels: " + Voxels.Count.ToString());

        CreateEdges();

        //SetupVoxelSubrenderComputeShader();

//         DirectLightVoxels();
//         if (ambientPass1) AmbientPass(1);
//         if (ambientPass2) AmbientPass(2);
//         if (ambientPass3) AmbientPass(3);
//         PlaceVoxelCamera(Voxels[debugVoxelIndex].globalPos,Voxels[debugVoxelIndex].normal);
//         bakeTimer.Stop();
        UnityEngine.Debug.Log("Created voxel debug cubes in: " + bakeTimer.Elapsed.ToString());
    }

    void SetupVoxelSubrenderComputeShader() {
        // Initialize data
        int count = Voxels.Count; // Number of billboards
        billboardData = new BillboardData[count];
        for (int i = 0; i < count; i++) {
            billboardData[i].globalPos = Voxels[i].globalPos;
            billboardData[i].size = Voxels[i].size;
            billboardData[i].normal = Voxels[i].normal;
            billboardData[i].up = Voxels[i].up;
            billboardData[i].right = Voxels[i].right;
            billboardData[i].spotAngle = Voxels[i].spotAngle;
            billboardData[i].range = Voxels[i].range;
            billboardData[i].voxelIndex = Voxels[i].voxelIndex; // For debug rendering each as unique color
            billboardData[i].textureIndex = Voxels[i].chunkIndex;
        }

        // Create buffer
        billboardBuffer = new ComputeBuffer(count, System.Runtime.InteropServices.Marshal.SizeOf(typeof(BillboardData)));
        billboardBuffer.SetData(billboardData);

        // Assign buffer to compute shader
        voxSubrender.SetBuffer(0, "billboards", billboardBuffer);
        voxSubrender.SetTexture(0, "Output", resultTexture); // Assign render texture
        voxSubrender.SetTexture(0,"_TextureAtlas",chunkAlbedo);
    }
    
    void RenderBillboards(int vox) { // TODO: Use to index into Voxels[] array instead of player camera
        voxSubrender.SetVector("camPos", Camera.main.transform.position);
        voxSubrender.SetMatrix("viewProj", Camera.main.projectionMatrix * Camera.main.worldToCameraMatrix);
        voxSubrender.SetVector("camRight", Camera.main.transform.right);
        voxSubrender.SetVector("camUp", Camera.main.transform.up);
        voxSubrender.SetVector("camForward", Camera.main.transform.forward);

        int threadGroupsX = Mathf.CeilToInt(billboardData.Length / 8.0f);
        voxSubrender.Dispatch(0, threadGroupsX, 1, 1);
    }


    private void PlaceVoxelCamera(Vector3 pos, Vector3 norm) {
        voxelCam.transform.position = pos;
        voxelCam.transform.up = Vector3.up;
        voxelCam.transform.forward = norm;
        voxelCam.transform.position += voxelCam.transform.forward * (2.56f / width / 2f);
        voxelCam.orthographic = false;
        voxelCam.fieldOfView = voxelFOV;
        voxelCam.nearClipPlane = voxelNearZ;
        voxelCam.farClipPlane = voxelFarZ;
    }
    
    private void DirectLightVoxels() {
        Color lighting;
        float[,] depthBuffer = new float[voxelRenderResolution,voxelRenderResolution];
        Vector3[,] colorBuffer = new Vector3[voxelRenderResolution,voxelRenderResolution];
        for (int i=0;i<Voxels.Count;i++) {
            if (Voxels[i].chunkObjectIndex < 0) continue; // Don't light lights

            lighting = Color.black;
            for (int y=0;y<voxelRenderResolution;y++) {
                for (int x=0;x<voxelRenderResolution;x++) {
                    depthBuffer[x,y] = voxelFarZ; // Clear depth buffer for this Voxel[i]'s view
                    colorBuffer[x,y] = Vector3.zero; // Also black out colorBuffer
                }
            }

            PlaceVoxelCamera(Voxels[i].globalPos,Voxels[i].normal);
            Matrix4x4 vpMatrix = voxelCam.projectionMatrix * voxelCam.worldToCameraMatrix;
            for (int j=0;j<Voxels.Count;j++) {
                if (j == i) continue; // Skip self
                if (Voxels[j].chunkObjectIndex == Voxels[i].chunkObjectIndex) continue; // Skip other voxels in same shared object
                if (Vector3.Dot((Voxels[j].globalPos - Voxels[i].globalPos).normalized,Voxels[i].normal) < maxDot) continue; // Frustum rejection

                float raydot = Vector3.Dot(-Voxels[j].normal,Voxels[i].normal);
                if (raydot < 0f && Voxels[j].chunkObjectIndex >= 0) continue;

                Vector4 localPos = vpMatrix * new Vector4(Voxels[j].globalPos.x, Voxels[j].globalPos.y, Voxels[j].globalPos.z, 1f);
                float xScreen = (localPos.x / localPos.w + 1) * 0.5f * voxelRenderResolution;
                float yScreen = (localPos.y / localPos.w + 1) * 0.5f * voxelRenderResolution;
                float perspectiveScale = (Vector2.Distance(new Vector2(xScreen,yScreen),new Vector2(voxelRenderResolutionHalf,voxelRenderResolutionHalf)) / voxelRenderResolutionHalf) * voxelVolumeFOVFac;
                float dist = Vector3.Distance(Voxels[j].globalPos,Voxels[i].globalPos);
                float voxelRadius = (voxelVolume / Mathf.Max(dist, voxelNearZ)) * perspectiveScale;
                if (Voxels[j].chunkObjectIndex < 0) voxelRadius *= Voxels[j].directLighting.r * lightVolumeMultiplier;

                // Handle edges explicitly
                int xMin = Mathf.Max(Mathf.FloorToInt(xScreen - voxelRadius), 0);
                int xMax = Mathf.Min(Mathf.FloorToInt(xScreen + voxelRadius), voxelRenderResolution - 1);
                int yMin = Mathf.Max(Mathf.FloorToInt(yScreen - voxelRadius), 0);
                int yMax = Mathf.Min(Mathf.FloorToInt(yScreen + voxelRadius), voxelRenderResolution - 1);

                // Use xPixel, yPixel for depth and color buffer checks
                float depth = dist / voxelFarZ;
                float intensity = 1f;//Voxels[j].directLighting.r;
                for (int xPixel = xMin; xPixel <= xMax; xPixel++) {
                    for (int yPixel = yMin; yPixel <= yMax; yPixel++) {
                        if (dist < voxelNearZ) { depthBuffer[xPixel,yPixel] = voxelFarZ; continue; }

                        if (depth < depthBuffer[xPixel, yPixel]) {
                            depthBuffer[xPixel, yPixel] = depth;
                            colorBuffer[xPixel, yPixel] = new Vector3(Voxels[j].diffuse.r * intensity, Voxels[j].diffuse.g * intensity, Voxels[j].diffuse.b * intensity);
                        }
                    }
                }
            }

            if (i == debugVoxelIndex) {
                UnityEngine.Debug.Log("Painting debugTex for i " + debugVoxelIndex.ToString());
                Texture2D debugTex = new Texture2D(voxelRenderResolution,voxelRenderResolution);
                debugTex.filterMode = FilterMode.Point;
                for (int y=0;y<voxelRenderResolution;y++) {
                    for (int x=0;x<voxelRenderResolution;x++) {
                        debugTex.SetPixel(x,y,new Color(colorBuffer[x,y].x,colorBuffer[x,y].y,colorBuffer[x,y].z,1f),0);
                    }
                }

                debugTex.Apply();
                Material matDebug = new Material(Shader.Find("Unlit/Texture"));
                matDebug.mainTexture = debugTex;
                mr.material = matDebug;
            }

            for (int y=0;y<voxelRenderResolution;y++) {
                for (int x=0;x<voxelRenderResolution;x++) {
                    lighting.r += colorBuffer[x,y].x;
                    lighting.g += colorBuffer[x,y].y;
                    lighting.b += colorBuffer[x,y].z;
                }
            }

            // Get average color of resultant 16x16 render
            int numPixels = averageDivisor;
            lighting.r /= numPixels;
            lighting.g /= numPixels;
            lighting.b /= numPixels;
            lighting.r = Mathf.Min(1f,lighting.r);
            lighting.g = Mathf.Min(1f,lighting.g);
            lighting.b = Mathf.Min(1f,lighting.b);
            Color final = new Color(lighting.r,// * Voxels[i].diffuse.r,
                                    lighting.g,// * Voxels[i].diffuse.g,
                                    lighting.b,// * Voxels[i].diffuse.b,
                                    1f);

            if (Voxels[i].chunkObjectIndex >= 0) SetDebugCubeColor(Voxels[i].debugCube,final);
            Voxels[i].directLighting = final; // Apply final ambient lighting.
        }

        for (int i=0;i<Voxels.Count;i++) {
            if (Voxels[i].chunkObjectIndex >= 0) continue; // Not a light

            Voxels[i].directLighting = Color.black; // Exclude lights from next pass.
        }
    }
    
    private void AmbientPass(int pass) {
        Color lighting;
        Vector3 raydir;
        float[,] depthBuffer = new float[voxelRenderResolution,voxelRenderResolution];
        Color[,] colorBuffer = new Color[voxelRenderResolution,voxelRenderResolution];
        for (int i=0;i<Voxels.Count;i++) { // Commented out to test just one voxel for now.
            if (Voxels[i].chunkObjectIndex < 0) continue; // Don't light lights

            lighting = Color.black;
            for (int y=0;y<voxelRenderResolution;y++) {
                for (int x=0;x<voxelRenderResolution;x++) {
                    depthBuffer[x,y] = voxelFarZ; // Clear depth buffer for this Voxel[i]'s view
                    colorBuffer[x,y] = Color.black; // Also black out colorBuffer
                }
            }
            
            PlaceVoxelCamera(Voxels[i].globalPos,Voxels[i].normal);
            Matrix4x4 vpMatrix = voxelCam.projectionMatrix * voxelCam.worldToCameraMatrix;
            for (int j=0;j<Voxels.Count;j++) {
                if (j == i) continue; // Skip self
                if (Voxels[j].chunkObjectIndex < 0) continue; // Skip lights
                if (Voxels[j].chunkObjectIndex == Voxels[i].chunkObjectIndex) continue; // Skip other voxels in same shared object
                
                float dist = Vector3.Distance(Voxels[j].globalPos,Voxels[i].globalPos);
                if (dist > Voxels[j].range && Voxels[j].chunkObjectIndex < 0) continue; // Skip rendering lights beyond the light's range

                float depth = dist / voxelFarZ;
                Vector3 viewDir = Voxels[i].normal.normalized;
                raydir = Voxels[j].globalPos - Voxels[i].globalPos;
                raydir = raydir.normalized;
                float frustDot = Vector3.Dot(raydir,viewDir);
                float maxDot = Mathf.Cos(Mathf.Deg2Rad * (voxelFOV * 0.5f));
                if (frustDot < maxDot) continue;
                
                float raydot = Vector3.Dot(-Voxels[j].normal,Voxels[i].normal);
                if (raydot < 0f) continue;

                Vector4 localPos = vpMatrix * new Vector4(Voxels[j].globalPos.x, Voxels[j].globalPos.y, Voxels[j].globalPos.z, 1f);
                float xScreen = (localPos.x / localPos.w + 1) * 0.5f * voxelRenderResolution;
                float yScreen = (localPos.y / localPos.w + 1) * 0.5f * voxelRenderResolution;
                float center = voxelRenderResolution / 2f;
                float perspectiveScale = Mathf.Max(1f,Mathf.Abs(xScreen - center)/(voxelRenderResolution * 0.5f) * voxelVolumeFOVFac); // scale to adjust for perspective distortion
                float voxelRadius = (voxelVolume / Mathf.Max(dist, voxelNearZ)) * perspectiveScale;
                int xStart = Mathf.FloorToInt(xScreen - voxelRadius);
                int xEnd = Mathf.FloorToInt(xScreen + voxelRadius);
                int yStart = Mathf.FloorToInt(yScreen - voxelRadius);
                int yEnd = Mathf.FloorToInt(yScreen + voxelRadius);

                // Handle edges explicitly
                int xMin = Mathf.Max(xStart, 0);
                int xMax = Mathf.Min(xEnd, voxelRenderResolution - 1);
                int yMin = Mathf.Max(yStart, 0);
                int yMax = Mathf.Min(yEnd, voxelRenderResolution - 1);

                // Use xPixel, yPixel for depth and color buffer checks
                for (int xPixel = xMin; xPixel <= xMax; xPixel++) {
                    for (int yPixel = yMin; yPixel <= yMax; yPixel++) {
                        if (dist < voxelNearZ) { depthBuffer[xPixel,yPixel] = voxelFarZ; continue; }
                        
                        if (depth < depthBuffer[xPixel, yPixel]) {
                            depthBuffer[xPixel, yPixel] = depth;
                            if (pass == 3) colorBuffer[xPixel, yPixel] = Voxels[j].ambientPass2;
                            if (pass == 2) colorBuffer[xPixel, yPixel] = Voxels[j].ambientPass1;
                            else if (pass == 1) colorBuffer[xPixel, yPixel] = Voxels[j].directLighting;
                        }
                    }
                }
            }
            
            if (i == debugVoxelIndex && pass == 3) {
                UnityEngine.Debug.Log("Painting debugTex for i " + debugVoxelIndex.ToString());
                Texture2D debugTex = new Texture2D(voxelRenderResolution,voxelRenderResolution);
                debugTex.filterMode = FilterMode.Point;
                for (int y=0;y<voxelRenderResolution;y++) {
                    for (int x=0;x<voxelRenderResolution;x++) {
                        debugTex.SetPixel(x,y,colorBuffer[x,y],0);
                    }
                }
                
                debugTex.Apply();
                Material matDebug = new Material(Shader.Find("Unlit/Texture"));
                matDebug.mainTexture = debugTex;
                mr.material = matDebug;
            }
            
            for (int y=0;y<voxelRenderResolution;y++) {
                for (int x=0;x<voxelRenderResolution;x++) {
                    lighting.r += colorBuffer[x,y].r;
                    lighting.g += colorBuffer[x,y].g;
                    lighting.b += colorBuffer[x,y].b;
                }
            }
            
            // Get average color of resultant 16x16 render
            int numPixels = averageDivisor;
            lighting.r /= numPixels;
            lighting.g /= numPixels;
            lighting.b /= numPixels;
            lighting.r = Mathf.Min(1f,lighting.r);
            lighting.g = Mathf.Min(1f,lighting.g);
            lighting.b = Mathf.Min(1f,lighting.b);
            Color final = new Color(lighting.r,// * Voxels[i].diffuse.r,
                                    lighting.g,// * Voxels[i].diffuse.g,
                                    lighting.b,// * Voxels[i].diffuse.b,
                                    1f);

            if (pass == 1) Voxels[i].ambientPass1 = final; // Apply final ambient lighting.
            else if (pass == 2) Voxels[i].ambientPass2 = final; // Apply final ambient lighting.
            else if (pass == 3) Voxels[i].ambientPass3 = final; // Apply final ambient lighting.
            
            Voxels[i].finalLighting = Voxels[i].directLighting + Voxels[i].ambientPass1 + Voxels[i].ambientPass2 + Voxels[i].ambientPass3;
            if (Voxels[i].chunkObjectIndex >= 0) SetDebugCubeColor(Voxels[i].debugCube,Voxels[i].finalLighting);
        }
    }
    
    private void SetDebugCubeColor(GameObject cube, Color col) {
        Material mat = new Material(Shader.Find("Unlit/Color"));
        mat.color = col;
        cube.GetComponent<Renderer>().material = mat;
    }
    
    private void CreateVoxels() {
        Voxels = new List<Loxel>();
        Transform tr;
        float cubeSize = 2.56f / width;
        for (int c=0;c<chunksToVoxelize.Length;c++) {
            tr = chunksToVoxelize[c].transform;
            Mesh msh = chunksToVoxelize[c].GetComponent<MeshFilter>().sharedMesh;
            float red = msh.colors[0].r;
            int chunkIndex = (int)(red * 255.0f);
            Color[] textureCols = chunkAlbedo.GetPixels(chunkIndex,0);
            int numPixelsInVoxel = (int)(128f / (float)width); // E.g. if width is 8, numPixelsInVoxel = 128 / 8 = 16;
            Vector3 sumColor = Vector3.zero;
            Color selected;
            Color[] voxelColors = new Color[width * width];
            for (int i = 0; i < width; i++) {
                for (int j = 0; j < width; j++) {
                    sumColor = Vector3.zero;
                    int startX = i * numPixelsInVoxel;
                    int startY = j * numPixelsInVoxel;

                    for (int pixX = startX; pixX < startX + numPixelsInVoxel; pixX++) {
                        for (int pixY = startY; pixY < startY + numPixelsInVoxel; pixY++) {
                            selected = textureCols[pixY * 128 + (127 - pixX)];
                            sumColor.x += selected.r;
                            sumColor.y += selected.g;
                            sumColor.z += selected.b;
                        }
                    }

                    int totalPixels = numPixelsInVoxel * numPixelsInVoxel;
                    Color vol = new Color(
                        sumColor.x / totalPixels,
                        sumColor.y / totalPixels,
                        sumColor.z / totalPixels,
                        1f
                    );

                    voxelColors[i * width + j] = vol;
                }
            }

            for (int x=0;x<width;x++) {
                for (int y=0;y<width;y++) {
                    float offsetX = (x * cubeSize) - 1.28f + (cubeSize * 0.5f);
                    float offsetY = 1.28f + (cubeSize * 0.5f);
                    float offsetZ = (y * cubeSize) - 1.28f + (cubeSize * 0.5f);
                    GameObject cube = MakeDebugCube(tr,cubeSize,offsetX,offsetY,offsetZ,c,Voxels.Count);
                    Loxel lox = new Loxel();
                    lox.globalPos = cube.transform.position;
                    lox.normal = -tr.up; // Green axis, card faces down on rotation 0,0,0
                    lox.diffuse = voxelColors[x * width + y];
                    lox.directLighting = lox.ambientPass1 = lox.ambientPass2 = lox.ambientPass3 = Color.black;
                    lox.debugCube = cube;
                    lox.size = voxelSize;
                    lox.chunkObjectIndex = c;
                    lox.chunkIndex = chunkIndex;
                    lox.voxelIndex = Voxels.Count;
                    lox.up = tr.right; // Red axis
                    lox.right = -tr.forward; // Blue axis, flipped due to card facing down in rotation 0,0,0
                    lox.spotAngle = 0f;
                    lox.range = 0f;
                    Voxels.Add(lox);
                }
            }
        }
    }
    
    public bool CheckForCellAtLocation(Vector3Int pos) {
        return    VoxelMap1.ContainsKey(pos)
               || VoxelMap2.ContainsKey(pos)
               || VoxelMap3.ContainsKey(pos);
    }

    // Add to 1 first, then 2, then 3.  VoxelMap2 voxels _always_ have a mate
    // in VoxelMap1, VoxelMap3 voxels _always_ have a mate in both VoxelMap1 & 2.
    public void AddVoxel(Vector3Int position, Loxel voxel) {
        if (!VoxelMap1.ContainsKey(position)) VoxelMap1[position] = voxel;
        else if (!VoxelMap2.ContainsKey(position)) VoxelMap2[position] = voxel;
        else if (!VoxelMap3.ContainsKey(position)) VoxelMap3[position] = voxel;
        else UnityEngine.Debug.Log("ERROR: Could not add voxel at " + position.ToString());
    }

    public Loxel GetVoxel(Vector3Int position, Vector3 rayDir) {
        List<Loxel> voxels = new List<Loxel>();
        if (VoxelMap1.TryGetValue(position, out Loxel voxel1)) voxels.Add(voxel1);
        if (VoxelMap2.TryGetValue(position, out Loxel voxel2)) voxels.Add(voxel2);
        if (VoxelMap3.TryGetValue(position, out Loxel voxel3)) voxels.Add(voxel3);
        if (voxels.Count == 0) return null; // No voxels at this position.

        Loxel bestVoxel = null;
        float bestDot = float.MinValue;
        for (int i=0;i<voxels.Count;i++) {
            float dot = Vector3.Dot(rayDir, voxels[i].normal);
            if (dot < 0 && dot > bestDot) {
                // Only consider voxels whose normals face the ray and are closer to alignment
                bestDot = dot;
                bestVoxel = voxels[i];
            }
        }

        return bestVoxel;
    }
    
    private GameObject MakeDebugCube(Transform parent, float cubeSize,float offsetX, float offsetY, float offsetZ, int chunkObjectIndex, int voxIndex) {
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.transform.parent = parent; // Put on parent
        cube.transform.localScale = new Vector3(cubeSize,cubeSize,cubeSize);
        cube.transform.localPosition = new Vector3(offsetX,offsetY,offsetZ); // Apply offset
        cube.transform.parent = null; // Make it separate from parent to get true position
        Note nt = cube.AddComponent<Note>();
        nt.note = "Chunk index: " + chunkObjectIndex.ToString() + ", Voxel index: " + voxIndex.ToString();
        return cube;
    }
    
    private void OnDestroy() {
        if (Application.isPlaying) {
            ShaderHelper.Release(billboardBuffer);
        }
    }
}
