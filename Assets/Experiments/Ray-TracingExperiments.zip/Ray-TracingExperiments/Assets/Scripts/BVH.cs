using UnityEngine;
using System;
using Unity.Mathematics;
using System.Text;
using System.Linq;

public class BVH {
    public readonly NodeList allNodes;
    public readonly Triangle[] allTris;
    public Triangle[] GetTriangles() => allTris;
    readonly BVHTriangle[] AllTriangles;

    public BVH(Vector3[] verts, int[] indices, Vector3[] normals, Color[] cols,
               Vector2[] uvs, Vector4[] tangents) {
        // Construct BVH
        allNodes = new NodeList();
        AllTriangles = new BVHTriangle[indices.Length / 3];
        BoundingBox bounds = new BoundingBox();

        for (int i = 0; i < indices.Length; i += 3) {
            float3 a = verts[indices[i + 0]];
            float3 b = verts[indices[i + 1]];
            float3 c = verts[indices[i + 2]];
            float3 centre = (a + b + c) / 3;
            float3 max = math.max(math.max(a, b), c);
            float3 min = math.min(math.min(a, b), c);
            AllTriangles[i / 3] = new BVHTriangle(centre, min, max, i);
            bounds.GrowToInclude(min, max);
        }

        allNodes.Add(new Node(bounds));
        Split(0, verts, 0, AllTriangles.Length);
        allTris = new Triangle[AllTriangles.Length];
        Color texArrayIndex = Color.black;
        for (int i = 0; i < AllTriangles.Length; i++) {
            BVHTriangle buildTri = AllTriangles[i];
            int vert1 = indices[buildTri.Index + 0];
            int vert2 = indices[buildTri.Index + 1];
            int vert3 = indices[buildTri.Index + 2];
            Vector3 a = verts[vert1];
            Vector3 b = verts[vert2];
            Vector3 c = verts[vert3];
            Vector3 norm_a = normals[vert1];
            Vector3 norm_b = normals[vert2];
            Vector3 norm_c = normals[vert3];
            texArrayIndex = Color.black;
            if (cols != null) {
                if (cols.Length > 0) {
                    texArrayIndex = cols[vert1]; // All are the same, just get 1.
                }
            }

            Vector2 uva = new Vector2(0f,0f);
            Vector2 uvb = new Vector2(0f,0f);
            Vector2 uvc = new Vector2(0f,0f);
            if (uvs != null) {
                if (vert1 < uvs.Length) uva = uvs[vert1];
                if (vert2 < uvs.Length) uvb = uvs[vert2];
                if (vert3 < uvs.Length) uvc = uvs[vert3];
            }
            
            Vector4 tana = tangents[vert1];
            Vector4 tanb = tangents[vert2];
            Vector4 tanc = tangents[vert3];
            
            allTris[i] = new Triangle(a,b,c,norm_a,norm_b,norm_c,texArrayIndex,
                                      uva,uvb,uvc,tana,tanb,tanc);
        }
    }

    void Split(int parentIndex, Vector3[] verts, int triGlobalStart, int triNum, int depth = 0) {
        const int MaxDepth = 256;
        Node parent = allNodes.Nodes[parentIndex];
        Vector3 size = parent.CalculateBoundsSize();
        float parentCost = NodeCost(size, triNum);

        (int splitAxis, float splitPos, float cost) = ChooseSplit(parent, triGlobalStart, triNum);

        if (cost < parentCost && depth < MaxDepth) {
            BoundingBox boundsLeft = new BoundingBox();
            BoundingBox boundsRight = new BoundingBox();
            int numOnLeft = 0;
            for (int i = triGlobalStart; i < triGlobalStart + triNum; i++) {
                BVHTriangle tri = AllTriangles[i];
                if (tri.Centre[splitAxis] < splitPos) {
                    boundsLeft.GrowToInclude(tri.Min, tri.Max);

                    BVHTriangle swap = AllTriangles[triGlobalStart + numOnLeft];
                    AllTriangles[triGlobalStart + numOnLeft] = tri;
                    AllTriangles[i] = swap;
                    numOnLeft++;
                } else {
                    boundsRight.GrowToInclude(tri.Min, tri.Max);
                }
            }

            int numOnRight = triNum - numOnLeft;
            int triStartLeft = triGlobalStart + 0;
            int triStartRight = triGlobalStart + numOnLeft;

            // Split parent into two children
            int childIndexLeft = allNodes.Add(new Node(boundsLeft, triStartLeft, 0));
            int childIndexRight = allNodes.Add(new Node(boundsRight, triStartRight, 0));

            // Update parent
            parent.StartIndex = childIndexLeft;
            allNodes.Nodes[parentIndex] = parent;

            // Recursively split children
            Split(childIndexLeft, verts, triGlobalStart, numOnLeft, depth + 1);
            Split(childIndexRight, verts, triGlobalStart + numOnLeft, numOnRight, depth + 1);
        } else {
            // Parent is actually leaf, assign all triangles to it
            parent.StartIndex = triGlobalStart;
            parent.TriangleCount = triNum;
            allNodes.Nodes[parentIndex] = parent;
        }
    }

    (int axis, float pos, float cost) ChooseSplit(Node node, int start, int count) {
        if (count <= 1) return (0, 0, float.PositiveInfinity);

        float bestSplitPos = 0;
        int bestSplitAxis = 0;
        const int numSplitTests = 5;

        float bestCost = float.MaxValue;

        // Estimate best split pos
        for (int axis = 0; axis < 3; axis++) {
            for (int i = 0; i < numSplitTests; i++) {
                float splitT = (i + 1) / (numSplitTests + 1f);
                float splitPos = Mathf.Lerp(node.BoundsMin[axis], node.BoundsMax[axis], splitT);
                float cost = EvaluateSplit(axis, splitPos, start, count);
                if (cost < bestCost) {
                    bestCost = cost;
                    bestSplitPos = splitPos;
                    bestSplitAxis = axis;
                }
            }
        }

        return (bestSplitAxis, bestSplitPos, bestCost);
    }

    float EvaluateSplit(int splitAxis, float splitPos, int start, int count) {
        BoundingBox boundsLeft = new BoundingBox();
        BoundingBox boundsRight = new BoundingBox();
        int numOnLeft = 0;
        int numOnRight = 0;
        for (int i = start; i < start + count; i++) {
            BVHTriangle tri = AllTriangles[i];
            if (tri.Centre[splitAxis] < splitPos) {
                boundsLeft.GrowToInclude(tri.Min, tri.Max);
                numOnLeft++;
            } else {
                boundsRight.GrowToInclude(tri.Min, tri.Max);
                numOnRight++;
            }
        }

        float costA = NodeCost(boundsLeft.Size, numOnLeft);
        float costB = NodeCost(boundsRight.Size, numOnRight);
        return costA + costB;
    }

    static float NodeCost(Vector3 size, int numTriangles) {
        float halfArea = size.x * size.y + size.x * size.z + size.y * size.z;
        return halfArea * numTriangles;
    }

    public struct Node {
        public float3 BoundsMin;
        public float3 BoundsMax;
        // Index of first child (if triangle count is negative) otherwise index of first triangle
        public int StartIndex;
        public int TriangleCount;

        public Node(BoundingBox bounds) : this() {
            BoundsMin = bounds.Min;
            BoundsMax = bounds.Max;
            StartIndex = -1;
            TriangleCount = -1;
        }

        public Node(BoundingBox bounds, int startIndex, int triCount) {
            BoundsMin = bounds.Min;
            BoundsMax = bounds.Max;
            StartIndex = startIndex;
            TriangleCount = triCount;
        }

        public Vector3 CalculateBoundsSize() => BoundsMax - BoundsMin;
        public Vector3 CalculateBoundsCentre() => (BoundsMin + BoundsMax) / 2;
    }

    public struct BoundingBox {
        public float3 Min;
        public float3 Max;
        public float3 Centre => (Min + Max) / 2;
        public float3 Size => Max - Min;
        bool hasPoint;

        public void GrowToInclude(float3 min, float3 max) {
            if (hasPoint) {
                Min.x = min.x < Min.x ? min.x : Min.x;
                Min.y = min.y < Min.y ? min.y : Min.y;
                Min.z = min.z < Min.z ? min.z : Min.z;
                Max.x = max.x > Max.x ? max.x : Max.x;
                Max.y = max.y > Max.y ? max.y : Max.y;
                Max.z = max.z > Max.z ? max.z : Max.z;
            } else {
                hasPoint = true;
                Min = min;
                Max = max;
            }
        }
    }


    public readonly struct BVHTriangle {
        public readonly float3 Centre;
        public readonly float3 Min;
        public readonly float3 Max;
        public readonly int Index;

        public BVHTriangle(float3 centre, float3 min, float3 max, int index) {
            Centre = centre;
            Min = min;
            Max = max;
            Index = index;
        }
    }

    //public Node[] GetNodes() => allNodes.Nodes.AsSpan(0, allNodes.NodeCount).ToArray();
    public Node[] GetNodes() => allNodes.Nodes.Take(allNodes.NodeCount).ToArray();

    public class NodeList {
        public Node[] Nodes = new Node[256];
        int Index;

        public int Add(Node node) {
            if (Index >= Nodes.Length) Array.Resize(ref Nodes, Nodes.Length * 2);
            int nodeIndex = Index;
            Nodes[Index++] = node;
            return nodeIndex;
        }

        public int NodeCount => Index;

    }
}
