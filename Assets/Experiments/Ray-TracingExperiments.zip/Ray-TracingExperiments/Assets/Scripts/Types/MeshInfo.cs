using UnityEngine;

public struct MeshInfo {
	public int triangleStartIndex;
	public int triangleCount;
	public Vector3 boundsMin;
	public Vector3 boundsMax;

	public MeshInfo(int triangleStartIndex, int triangleCount, Bounds bounds) {
		this.triangleStartIndex = triangleStartIndex;
		this.triangleCount = triangleCount;
		this.boundsMin = bounds.min;
		this.boundsMax = bounds.max;
	}
}
