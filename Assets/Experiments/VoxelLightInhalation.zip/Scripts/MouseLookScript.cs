﻿using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections;
using System.Runtime.InteropServices;
using System.Text;

public class MouseLookScript : MonoBehaviour {
    // External references
	public GameObject player;
	public float sensitivity = 0.5f;
	public float fov = 65f;
	public Vector2 lastMousePos;
	
    [HideInInspector] public Vector2 cursorHotspot;
    [HideInInspector] public Vector3 cameraFocusPoint;
    public float yRotation;
    [HideInInspector] public float xRotation;
    private float zRotation;
    private float yRotationV;
    private float xRotationV;
    private float zRotationV;
    private float currentZRotation;
    private string mlookstring1;
    [HideInInspector] public Camera playerCamera;
    private GameObject heldObject;
	private Quaternion tempQuat;
	private Vector3 tempVec;
    private RaycastHit tempHit;
	private string mouseX = "Mouse X";
	private string mouseY = "Mouse Y";
	private Vector3 cursorPoint;
	private float rotSpeedX = 0f;
	private float rotSpeedY = 0f;
	public float joyXStartTime;
	public float joyYStartTime;
	public float joyXSignLast;
	public float joyYSignLast;
    
	public static MouseLookScript a;

	void Awake() {
		a = this;
		a.playerCamera = GetComponent<Camera>(); // Needed elsewhere, do early.
	}

    void Start (){
		//Cursor.lockState = CursorLockMode.Locked;
		playerCamera.depthTextureMode = DepthTextureMode.Depth;
		yRotation = 0;
		xRotation = 0;
    }

	void Update() {
		// PROCESS INPUT SIGNALS
		// ----------------------------------------------------------------
		float angX = 0f; // Angle change for X.
		float angY = 0f; // Angle change for Y.
		// Handle mouse input from a standard mouse.
		float deltaX = Input.GetAxisRaw(mouseX) * sensitivity * fov;
		float deltaY = Input.GetAxisRaw(mouseY) * sensitivity * fov;

		// Handle thumbstick input from a controller.
		Vector2 rightThumbstick = new Vector2(0f,0f);

		// X
		float signX = rightThumbstick.x > 0.0f ? 1.0f
					  : rightThumbstick.x < 0.0f ? -1.0f : 0f;
		if (signX != joyXSignLast) {
			joyXStartTime = Time.time; // Zero crossing.
			rotSpeedX = 0f; // Reset integrator windup.
		}

		joyXSignLast = signX;
		rightThumbstick.x *= sensitivity * 20f;
		rotSpeedX += rightThumbstick.x; // Integrate to give fine initial.
		if (rightThumbstick.x == 0f) rotSpeedX = 0f;
		if (rotSpeedX != 0f) deltaX = rotSpeedX;

		// Y
		float signY = rightThumbstick.y > 0.0f ? 1.0f
					  : rightThumbstick.y < 0.0f ? -1.0f : 0f;
		if (signY != joyYSignLast) {
			joyYStartTime = Time.time; // Zero crossing.
			rotSpeedY = 0f; // Reset integrator windup.
		}

		joyYSignLast = signY;
		rightThumbstick.y *= sensitivity * 20f;
		rotSpeedY += rightThumbstick.y; // Integrate to give fine initial.
		if (rightThumbstick.y == 0) rotSpeedY = 0f;
		if (rotSpeedY != 0f) deltaY = rotSpeedY;

		// Apply input delta from mouse or controller to angles.
		if (signX != 0f || signY != 0f) {
			// Using controller, use integrated deltas.
			angX = deltaX;
			angY = deltaY;
		} else {
			// Using mouse, map input to deg per screen half / screen.
			angX = deltaX * ((fov / 2f) / Screen.width / 2f);
			angY = deltaY * ((fov / 2f) / Screen.height / 2f);
		}

		// High pass filter to prevent jumpy behavior.
		if (angX > fov) angX = fov;
		if (angY > fov) angY = fov;
		xRotation -= angY;
		xRotation = Mathf.Clamp(xRotation, -90f, 90f); // Limit up/down.
		yRotation += angX;
		transform.localRotation = Quaternion.Euler(xRotation,yRotation,0f);
		float xCenter = (float)Screen.width * 0.5f;
		float yCenter = (float)Screen.height * 0.5f;
		float xOffset = ((float)Input.mousePosition.x - xCenter);
		float yOffset = ((float)Input.mousePosition.y - yCenter);
	}

	// Clamp cyberspace up/down look rotation to with in +/- 360f.
	float Clamp0360(float val) {
		return (val - (Mathf.CeilToInt(val*(1f/360f)) * 360f)); // Subtract out 360 times the number of times 360 fits within val.
	}
}
