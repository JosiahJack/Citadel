using UnityEngine;
using UnityEngine.Rendering;
using System.Collections.Generic;

public class RayTracingManager : MonoBehaviour {
    public Camera cam;
    public Light[] lights;
    public Texture2DArray textureArray;
    public Texture2DArray textureArrayNorm;
    public Texture2DArray textureArraySpec;
    public LightTracer[] preRenderLights;
    public bool traceOn = true;

    [Header("Main Settings")]
    [SerializeField, Range(0, 32)] int maxBounceCount = 1;
    [SerializeField, Min(0)] float focusDistance = 1;

    [Header("References")]
    [SerializeField] Shader rayTracingShader;
    [SerializeField] Shader accumulateShader;

    // Materials and render textures
    Material rayTracingMaterial;
    RenderTexture resultTexture;

    // Buffers
    ComputeBuffer triangleBuffer;
    ComputeBuffer nodeBuffer;
    ComputeBuffer modelBuffer;
    ComputeBuffer lightBuffer;

    MeshInfo[] meshInfo;
    Model[] models;
    bool hasBVH;
    int lastScreenx;
    int lastScreeny;
    
    private void OnEnable() {
        if (traceOn) cam.cullingMask = 0;
        hasBVH = false;
        lastScreenx = Screen.width;
        lastScreeny = Screen.height;
    }

    private void Update() {
        //UpdateLightBuffer();
    }

    void UpdateLightBuffer() {
        LightDataLists ldata = CreateAllLightData();
        ShaderHelper.CreateStructuredBuffer(ref lightBuffer, ldata.lightData);
        if (rayTracingMaterial == null) return;
        
        rayTracingMaterial.SetBuffer("Lights", lightBuffer);
    }

    // Called after any camera (e.g. game or scene camera) has finished rendering into the src texture
    void OnRenderImage(RenderTexture src, RenderTexture target) {
        if (!Application.isPlaying) {
            Graphics.Blit(src, target); // Draw the unaltered camera render to the screen
            return;
        }

        InitFrame();
//         for (int i=0;i<preRenderLights.Length;i++) {
//             preRenderLights[i].RenderLight(triangleBuffer,nodeBuffer,modelBuffer);
//         }

        if (traceOn) {
            Graphics.Blit(null, target, rayTracingMaterial);
        } else {
            Graphics.Blit(src, target); // Draw the unaltered camera render to the screen
        }
    }

    void InitFrame() {
        // Create materials used in blits
        if (rayTracingMaterial == null || rayTracingMaterial.shader != rayTracingShader) {
            ShaderHelper.InitMaterial(rayTracingShader, ref rayTracingMaterial);
        }
        
        //ShaderHelper.InitMaterial(accumulateShader, ref accumulateMaterial);
        if (Screen.width != lastScreenx || Screen.height != lastScreeny) {
            ShaderHelper.CreateRenderTexture(ref resultTexture, Screen.width, Screen.height, FilterMode.Bilinear, ShaderHelper.RGBA_SFloat, "Result");
        }
        
        lastScreenx = Screen.width;
        lastScreeny = Screen.height;
        
        if (!hasBVH) {
            ShaderHelper.CreateRenderTexture(ref resultTexture, Screen.width, Screen.height, FilterMode.Bilinear, ShaderHelper.RGBA_SFloat, "Result");
            models = FindObjectsOfType<Model>();
            MeshDataLists data = CreateAllMeshData(models);
            hasBVH = true;
            //meshInfo = data.meshInfo.ToArray();
            meshInfo = new MeshInfo[data.meshInfo.Count]; // Assuming meshInfo is a list
            data.meshInfo.CopyTo(meshInfo);
            ShaderHelper.CreateStructuredBuffer(ref modelBuffer, meshInfo);

            // Triangles buffer
            ShaderHelper.CreateStructuredBuffer(ref triangleBuffer, data.triangles);
            rayTracingMaterial.SetBuffer("Triangles", triangleBuffer);
            rayTracingMaterial.SetInt("triangleCount", triangleBuffer.count);

            // Node buffer
            ShaderHelper.CreateStructuredBuffer(ref nodeBuffer, data.nodes);
            rayTracingMaterial.SetBuffer("Nodes", nodeBuffer);
            
            // Point lights (well, they aren't 100% points due to jitter)
            LightDataLists ldata = CreateAllLightData();
            ShaderHelper.CreateStructuredBuffer(ref lightBuffer, ldata.lightData);
            rayTracingMaterial.SetBuffer("Lights", lightBuffer);
        }
        
        UpdateModels();
        UpdateCameraParams(Camera.current); // Update data
        SetShaderParams();
    }

    void SetShaderParams() {
        rayTracingMaterial.SetInt("MaxBounceCount", maxBounceCount);
        rayTracingMaterial.SetTexture("_MainTexArray",textureArray);
        rayTracingMaterial.SetTexture("_MainTexArrayNorm",textureArrayNorm);
        rayTracingMaterial.SetTexture("_MainTexArraySpec",textureArraySpec);
    }

    void UpdateCameraParams(Camera cam) {
        float planeHeight = focusDistance * Mathf.Tan(cam.fieldOfView * 0.5f * Mathf.Deg2Rad) * 2;
        float planeWidth = planeHeight * cam.aspect;
        // Send data to shader
        rayTracingMaterial.SetVector("ViewParams", new Vector3(planeWidth, planeHeight, focusDistance));
        rayTracingMaterial.SetMatrix("CamLocalToWorldMatrix", cam.transform.localToWorldMatrix);
    }

    void UpdateModels() {
        for (int i = 0; i < models.Length; i++) {
            meshInfo[i].WorldToLocalMatrix = models[i].transform.worldToLocalMatrix;
            meshInfo[i].LocalToWorldMatrix = models[i].transform.localToWorldMatrix;
        }
        
        modelBuffer.SetData(meshInfo);
        rayTracingMaterial.SetBuffer("ModelInfo", modelBuffer);
        rayTracingMaterial.SetInt("modelCount", models.Length);
        rayTracingMaterial.SetInt("lightsCount", lights.Length);
    }

    MeshDataLists CreateAllMeshData(Model[] models) {
        MeshDataLists allData = new MeshDataLists();
        //Dictionary<Mesh, (int nodeOffset, int triOffset)> meshLookup = new Dictionary<int nodeOffset,int triOffset>();
        Dictionary<Mesh, (int nodeOffset, int triOffset)> meshLookup = new Dictionary<Mesh, (int nodeOffset, int triOffset)>();

        foreach (Model model in models) {
            // Construct BVH if this is the first time seeing the current mesh (otherwise reuse)
            if (!meshLookup.ContainsKey(model.Mesh)) {
                meshLookup.Add(model.Mesh, (allData.nodes.Count, allData.triangles.Count));
                BVH bvh = new BVH(model.Mesh.vertices,model.Mesh.triangles,
                                  model.Mesh.normals,model.Mesh.colors,
                                  model.Mesh.uv,model.Mesh.tangents);
                
                //if (model.logBVHStats) Debug.Log($"BVH Stats: {model.gameObject.name}\n{bvh.stats}");
                allData.triangles.AddRange(bvh.GetTriangles());
                allData.nodes.AddRange(bvh.GetNodes());
            }

            // Create the mesh info
            allData.meshInfo.Add(new MeshInfo() {
                NodeOffset = meshLookup[model.Mesh].nodeOffset,
                TriangleOffset = meshLookup[model.Mesh].triOffset,
                WorldToLocalMatrix = model.transform.worldToLocalMatrix
            });
        }

        return allData;
    }

    class MeshDataLists {
        public List<Triangle> triangles = new List<Triangle>();
        public List<BVH.Node> nodes = new List<BVH.Node>();
        public List<MeshInfo> meshInfo = new List<MeshInfo>();
    }
    
    LightDataLists CreateAllLightData() {
        LightDataLists allData = new LightDataLists();
        foreach (Light lit in lights) {
            if (!lit.enabled) continue;
            if (!lit.gameObject.activeInHierarchy) continue;

            float ang = lit.type == LightType.Spot ? lit.spotAngle : 0;
            allData.lightData.Add(new LightData() {
                color = lit.color,
                position = lit.transform.position,
                intensity = lit.intensity,
                range = lit.range,
                direction = -lit.transform.forward,
                angle = ang
            });
        }

        return allData;
    }

    class LightDataLists {
        public List<LightData> lightData = new List<LightData>();
    }
    
    struct LightData {
        public Color color;
        public Vector3 position;
        public float intensity;
        public float range;
        public Vector3 direction;
        public float angle;
    }

    void OnDestroy() {
        if (Application.isPlaying) {
            ShaderHelper.Release(triangleBuffer, nodeBuffer, modelBuffer, lightBuffer);
            ShaderHelper.Release(resultTexture);
            Destroy(rayTracingMaterial);
        }
    }

    void OnValidate() {

    }

    struct MeshInfo {
        public int NodeOffset;
        public int TriangleOffset;
        public Matrix4x4 WorldToLocalMatrix;
        public Matrix4x4 LocalToWorldMatrix;
    }
}
