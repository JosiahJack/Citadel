﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UCompile;

public class ScriptPreCompileBones : MonoBehaviour {
	[Header("NOTE: Tooltips provide useful information")]
	[Tooltip("Must be identical to the name of the class in the code")]
	public string classID;


	[TextArea(30,50)]
	public string code = "";

	bool compiled = false;

	/*public void compileBone (){
		CSScriptEngine engine = new CSScriptEngine ();

		#region Compile main bone
		for (int i = 0; i < allUsings.Length; i++) { //Add the libraries being used
			engine.AddUsings ("using " + allUsings [i] + ";");
		}
			
		//Type compiledCode = engine.CompileType (preCompile.classID, typeCode);
		engine.CompileType (classID, @code);
		#endregion


		#region Setup compiled bone

		IScript result = engine.CompileCode(@"gameobject.AddComponent<" + @classID + @">();");

		#endregion


		print (result);
		result.Execute ();
	}

	public void compileFakeBone (){
		CSScriptEngine engine = new CSScriptEngine ();

		#region Compile main bone
		engine.AddUsings ("using UnityEngine;");
		engine.AddUsings ("using System.Collections;");
		engine.AddUsings ("using System.Collections.Generic;");





		string typeCode = @"
		public class HiaPuut : MonoBehaviour{
			void Update(){
				this.gameObject.transform.Translate (.1f, .1f, .1f);
			}
		}";


		engine.CompileType ("HiaPuut", typeCode);
		#endregion


		#region Setup compiled bone

		IScript result = engine.CompileCode(@"gameObject.AddComponent<HiaPuut>();");

		#endregion


		print (result);
		result.Execute ();
	}

	public void compileFakeBone2 (){
		CSScriptEngine engine = new CSScriptEngine();

		engine.AddUsings("using UnityEngine;");

		string typeCode = @"
                
                                public class ColourChanger : MonoBehaviour{
                                    void Update()
                                    {
                                        if (Input.GetKeyDown(KeyCode.C))
                                        {
                                            this.gameObject.GetComponent<MeshRenderer>().material.color = new Color(Random.value, Random.value, Random.value);
                                        }
                                    }
                                }

                              ";

		engine.CompileType("ColorChanger", typeCode);

		IScript result = engine.CompileCode(@"
                                                 GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                                 cube.AddComponent<ColourChanger>();
                                               ");
		result.Execute();
	}
*/
	void Start(){
		//compileFakeBone ();


	}



}



