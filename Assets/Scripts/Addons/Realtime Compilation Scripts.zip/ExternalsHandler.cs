﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using UCompile;

public class ExternalsHandler : MonoBehaviour {

	/// When referring to anything stored inside these dictionaries, make sure to refer to the 'slug' of that object as the string.
	/// This here is the master dictionary, it is a dictionary of dictionaries. It stores dictionaries which store the assets inside of them!

	public Dictionary<string, Dictionary<string, GameObject>> assetDictionary = new Dictionary<string, Dictionary<string, GameObject>> ();

	[Tooltip("Case sensitive! Write the name of the library you wish this class to use, write without the 'using' or ';'. " +
		"So, instead of writing 'using UnityEngine;', just use 'UnityEngine'.")]
	public string[] allUsings; //Pretty much determines what all the classes will be able to access

	[HideInInspector]
	public GameObject theObject;

	string assetBundlePath;

	public string[] subPaths; //All subpaths to check for assetbundles (This is how you split item assets from vehicles, buildings, maps, so on)


	CSScriptEngine engine = new CSScriptEngine ();

	/// This class handles the compiling and building of the gameobjects too

	#region Retrieve assetfiles
	public void loadAllAssets(string path, string[] subPathsArray){

		//DebugClean.Log ("loadAllAssets is running");

		foreach (string subPath in subPathsArray){

			//DebugClean.Log ("loadAllAssets foreach is now running on: " + subPath);

			//Check to see if the mod subfolder exists, if not then create it
			if (!Directory.Exists (path + "/" + subPath)) {
				
				Directory.CreateDirectory (path + "/" + subPath);
				//DebugClean.Log ("mods/" + subPath + "file directory created!");
			}

			//Check to see if we have a matching sub-dictionary, if not then create one
			if (!assetDictionary.ContainsKey (subPath)) {//If the sub-dictionary doesn't exist
				//DebugClean.Log("\tCreated SuperDictionary Subpath: " + subPath);
				assetDictionary.Add(subPath, new Dictionary<string, GameObject>()); //Add a new subdictionary to the super dictionary		
			}

			//Load the asset, instantiate them into GameObject's, compile their marrows, then save them to the dictionary
			GameObject[] assetObjects = loadAssetsInFiles (path + "/" + subPath).ToArray();

			foreach(GameObject obj in assetObjects){
				//DebugClean.Log (obj.name);
			}

				for (int i = 0; i < assetObjects.Length; i++) {
					GameObject objectToAdd = processGameObject (assetObjects[i]);

					assetDictionary [subPath].Add (objectToAdd.name, objectToAdd);
				}


			//Iterate through and print everything in the assetObjects array
			foreach(GameObject assetObject in assetObjects){
				//DebugClean.Log (assetObject);
			}
			
		}
	}

	public List<GameObject> loadAssetsInFiles(string fullPath){
		
		List<GameObject> assets = new List<GameObject> (); //This is what needs to be returned

		string assetPath;//The path that will be used to load the individual asset

		//DebugClean.Log ("Searching for assets at: " + fullPath);

		//Find all the assets that are actually stored in the subPath file
		DirectoryInfo info = new DirectoryInfo(fullPath);
		FileInfo[] fileInfo = info.GetFiles ();

		if (fileInfo.Length != 0) {

			foreach (FileInfo file in fileInfo) {
				assetPath = file.Directory + "/" + file.Name;

				AssetBundle bundle = AssetBundle.LoadFromFile (assetPath);

				if (bundle == null) { //If the asset bundle doesn't exist, then state it!
					//DebugClean.Log ("\t\t\tAssetBundle is 'null'");
				} else {//If asset bundle exists, load it
					//DebugClean.Log ("\t\t\tAssetBundle = " + bundle);
				
					//string[] names = bundle.GetAllAssetNames ();//This line is just for the debug 'foreach' below

					/*foreach (string name in names) { //Just prints out the names of all the loaded assets
						//DebugClean.Log ("\t\t\tassetName: " + name);
					}*/

					GameObject[] loadedAssets = bundle.LoadAllAssets<GameObject> ();

					foreach (GameObject thing in loadedAssets) {
						//DebugClean.Log ("\t\t\t\tLoadedAssets: " + thing.name);
					}

					assets.AddRange (loadedAssets);
				}
				//DebugClean.Log ("\tFinished with this asset");
			}
		} else {
			//DebugClean.Log ("\tNothing in this asset folder");
		}

		//DebugClean.Log ("\tloadAssetsInFiles is finished with: " + fullPath);

		return assets; //Return all the assets we found in this subfile
	}


	#endregion


	#region Compilation
	/*void gameObjectArrayToDictionary(GameObject[] gameObjects, ref Dictionary<string, GameObject> dictionary){
		for(int i = 0; i < gameObjects.Length; i++){
			addGameObjectToDictionary (gameObjects[i], ref dictionary);
		}
	}*/

	/// <summary>
	/// Processes the game object and returns the fininshed gameobject. (Is renamed to whatever the slug is set to)
	/// </summary>
	/// <param name="gameObjectToProcess">Game object to process.</param>
	GameObject processGameObject(GameObject gameObjectToProcess){
		gameObjectToProcess = searchForBonesRecursive (gameObjectToProcess);

		return gameObjectToProcess;
	}


	void compilePreCompiles(ScriptPreCompileBones preCompile){//Compiles the preCompile scripts

		#region Compile main code

		string typeCode = preCompile.@code;

		engine.CompileType (preCompile.classID, typeCode);

		#endregion


		#region Setup compiled bone

		//string codeType = "preCompile.gameObject.AddComponent<" + preCompile.classID + ">();";

		string codeType = "GameObject theObject = GameObject.Find(\"_SCRIPTS_\").GetComponent<ExternalsHandler>().theObject;" +
			"ScriptPreCompileBones bone = theObject.GetComponent<ScriptPreCompileBones>();" +
			"theObject.AddComponent<" + preCompile.classID + ">();";

		IScript result = engine.CompileCode(@codeType);

		#endregion


		result.Execute ();
	}

	GameObject searchForBonesRecursive(GameObject objectToSearch){
		//Returns a gameobject with all the bones compiled
		objectToSearch = Instantiate(objectToSearch);//Firstly, create a copy of the object, then freeze it so we can edit it's properties

		objectToSearch.name.Replace ("(Clone)", "");

		//DebugClean.Log ("Instantiated: " + objectToSearch.name);

		//Compile marrow on parent (Shhh, I know this could have been done more cleanly)
		ScriptPreCompileBones[] unCompiledBones = objectToSearch.GetComponents<ScriptPreCompileBones>();

		//Make sure we actually have bones on this object
		if (unCompiledBones.Length != 0) {

			foreach (ScriptPreCompileBones bone in unCompiledBones) {
				theObject = objectToSearch;
				compilePreCompiles (bone);
				Destroy (bone); //Delete this bone, we don't need it anymore
			}
		}



		//Recurse and compile bones in children
		foreach(Transform child in objectToSearch.transform){
			unCompiledBones = child.gameObject.GetComponents<ScriptPreCompileBones> ();

			if (unCompiledBones.Length != 0) {//If we have a bone, then compile it. Otherwise, just get onto the next object
				foreach (ScriptPreCompileBones bone in unCompiledBones) {
					theObject = objectToSearch;
					compilePreCompiles (bone);
					Destroy (bone); //Delete this bone, we don't need it anymore
				}
			}
		}

		//Quickly disable this obect so none of its scripts run
		objectToSearch.SetActive (false);
		return objectToSearch;
	}//Should be run on everything before it enters the dictionary
	#endregion

	void Start(){
		assetBundlePath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/GameName/mods";

		//DebugClean.Log (assetBundlePath);

		AddCompilationFailedHandler ();

		for(int i = 0; i < allUsings.Length; i++){ //Add the libraries being used
			engine.AddUsings ("using " + allUsings[i] + ";");
		}


		//Compile stuff on the object


		loadAllAssets (assetBundlePath, subPaths);
		//gameObjectArrayToDictionary (gameObjectArray, ref assetItems);

	}

	void Update(){
		
	}



	#region Compiling Failed/Succeed Handling
	//Here we determine which method is going to automatically be invoked when compilation ends with errors
	void AddCompilationFailedHandler()
	{

		engine.AddOnCompilationFailedHandler(OnCompilationFailedAction);
	}



	//Method of type Action<CompilerOutput> that will be executed on failed compilation(with errors)
	//Outputs errors occured during compilation to editor console
	public void OnCompilationFailedAction(CompilerOutput output)
	{
		for (int i = 0; i < output.Errors.Count; i++)
			Debug.LogError(output.Errors[i]);
		for (int i = 0; i < output.Warnings.Count; i++)
			Debug.LogWarning(output.Warnings[i]);
	}

	//-------------------------------------------------------------------------------------------------

	//Here we determine which method is going to automatically be invoked when compilation ends without errors
	void AddCompilationSucceededHandler()
	{
		engine.AddOnCompilationSucceededHandler(OnCompilationSucceededAction);
	}

	//Method of type Action<CompilerOutput> that will be executed on succesfull compilation(without errors)
	//Outputs warnings occured during compilation to editor console
	public void OnCompilationSucceededAction(CompilerOutput output)
	{
		for (int i = 0; i < output.Warnings.Count; i++)
			Debug.LogWarning(output.Warnings[i]);
	}
	#endregion


}
